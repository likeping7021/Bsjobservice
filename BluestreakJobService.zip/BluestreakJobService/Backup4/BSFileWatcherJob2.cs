﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Configuration;

namespace Bluestreak.BSJobService
{
    public partial class BSFileWatcherJob
    {
        #region private methods
        /// <summary>
        /// When a new file comes, we need to update the schedule parameter for the schedule Id
        /// </summary>
        private void UpdateScheduleForNewFile(int jobId)
        {
            UnzipFiles();
            DirectoryInfo dir = new DirectoryInfo(_BlueStreakFilePath);
            FileInfo[] Files = dir.GetFiles();
            foreach (FileInfo file in Files)
            {
                string filePath = string.Empty;
                DateTime DteCompareTime = ComparedDate(file, _lookbackDuration);
                _fileMatch = _fileMatch.Trim();
                if (_fileMatch != string.Empty)
                {
                    if (Regex.IsMatch(file.Name, _fileMatch) && DteCompareTime > DateTime.Now && Path.GetExtension(file.Name).ToUpper() == ".CSV")
                    {
                        string campaignName = file.Name.Substring(0, file.Name.IndexOf("_"));
                        bool isCompaignExist = true;
                        int campaignId = CheckCampaign(campaignName, file.FullName, ref isCompaignExist);
                        if (campaignId != -99 && campaignId != -999)
                        {
                            string AdvPath = ConfigurationSettings.AppSettings["ADVFOLDER"].ToString() + _shortName + "\\" + "^" + campaignId;
                            filePath = ConfigurationSettings.AppSettings["ADVFOLDER"].ToString() + _shortName + "\\" + "^" + campaignId + "\\" + "^temp" + "\\" + file.Name;

                            if (File.Exists(filePath))
                            {
                                File.Delete(filePath);
                            }

                            if (!Directory.Exists(AdvPath))
                            {
                                //Directory.CreateDirectory(ConfigurationSettings.AppSettings["ADVFOLDER"].ToString() + _shortName + "\\" + "^" + campaignId);
                                Directory.CreateDirectory(AdvPath);
                                PublicFunctionUtil.copyDirectory(ConfigurationSettings.AppSettings["TempfolderForNewCampaign"].ToString(), ConfigurationSettings.AppSettings["ADVFOLDER"].ToString() + _shortName + "\\" + "^" + campaignId);
                            }

                            File.Copy(_BlueStreakFilePath + "\\" + file.Name, filePath);
                            this.LogMessage(jobId, string.Format("Found new file {0}: ", file.Name));
                            File.Delete(_BlueStreakFilePath + "\\" + file.Name);

                            //Remove to history folder
                            //File.Copy(_BlueStreakFilePath + "\\" + file.Name, _BlueStreakFilePath + "\backup");
                            //File.delete(_BlueStreakFilePath + "\\" + file.Name);

                            _oQuery.SQL = "JobService_UpdateScheduleForNewFile";
                            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
                            _oQuery.ParamByName("filePath").AsString = filePath;
                            _oQuery.Open();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Unzip the newly uploaded files.
        /// </summary>
        private void UnzipFiles()
        {
            DirectoryInfo dir = new DirectoryInfo(_BlueStreakFilePath);
            
            FileInfo[] Files = dir.GetFiles();
            foreach (FileInfo file in Files)
            {
                DateTime DteCompareTime = ComparedDate(file, _lookbackDuration);
                if (Path.GetExtension(file.Name).ToUpper() == ".ZIP" && DteCompareTime > DateTime.Now)
                {
                    string filePath = string.Empty;
                    _fileMatch = _fileMatch.Trim();
                    if (_fileMatch != string.Empty)
                    {
                        if (Regex.IsMatch(file.Name, _fileMatch) )
                        {
                            PublicFunctionUtil.UnZipfiles(file.FullName, _BlueStreakFilePath);
                        }

                        DirectoryInfo[] Folders = dir.GetDirectories();
                        foreach (DirectoryInfo folder in Folders)
                        {
                            FileInfo[] subFolderFiles = folder.GetFiles();
                            foreach (FileInfo subFolderFile in subFolderFiles)
                            {
                                if (File.Exists(_BlueStreakFilePath + "\\" + subFolderFile.Name))
                                {
                                    File.Delete(_BlueStreakFilePath + "\\" + subFolderFile.Name);
                                }
                                subFolderFile.MoveTo(_BlueStreakFilePath + "\\" + subFolderFile.Name);
                            }
                            Directory.Delete(folder.FullName);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// /Check campaign accord the the fileName
        /// </summary>
        /// <param name="campaignName"></param>
        /// <param name="isCampaignExist"></param>
        /// <returns></returns>
        private int CheckCampaign(string campaignName, string filePath, ref bool isCompaignExist)
        {
            isCompaignExist = CheckCampaignNameExist(campaignName);

            GetLocale(filePath);
            if (!isCompaignExist)
            {
                AddNewCompaign(campaignName);
            }

            int campaignId = -99;
            _oQuery.SQL = "JobService_GetCampaignID";
            _oQuery.ParamByName("campaignName").AsString = campaignName;
            _oQuery.ParamByName("advid").AsInteger = _advid;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                campaignId = _oQuery.FieldByName("campaignId").AsInteger;
                _shortName = _oQuery.FieldByName("shortName").AsString;
            }
            return campaignId;
        }

        /// <summary>
        /// Get the file compare date
        /// </summary>
        /// <param name="fileinfo"></param>
        /// <returns></returns>
        private DateTime ComparedDate(FileInfo fileinfo, string lookbacktime)
        {
            string[] backtime = lookbacktime.Split(':');
            int hours = Convert.ToInt32(backtime[0]);
            int minutes = Convert.ToInt32(backtime[1]) * ((hours < 0) ? -1 : 1);

            DateTime dteCreationTime = fileinfo.LastWriteTime;
            return dteCreationTime.AddHours(hours).AddMinutes(minutes);
        }

        private JobStatus CheckFTPSynJobStatus()
        {
            JobStatus FTPSynJobStatus = JobStatus.Failed;
            _oQuery.SQL = "JobService_GetFTPSynJobStatus";
            _oQuery.ParamByName("fileWatcher_QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                FTPSynJobStatus = (JobStatus)_oQuery.FieldByName("Job_Status").AsInteger;
            }

            return FTPSynJobStatus;
        }

        ///
        private void AddNewCompaign(string campaignName)
        {
            _oQuery.SQL = "ion_insertCampaign";
            _oQuery.ParamByName("advname").AsString = _advname;
            _oQuery.ParamByName("projname").AsString = campaignName;
            _oQuery.ParamByName("advid").AsInteger = _advid;
            _oQuery.ParamByName("targeted").AsInteger = 0;
            _oQuery.ParamByName("active").AsInteger = 1;
            _oQuery.ParamByName("campaignID").AsString = "DEFAULT";
            _oQuery.ParamByName("designer").AsInteger = 0;
            _oQuery.ParamByName("defaultLocale").AsString = _locale;
            _oQuery.ParamByName("PREnabled").AsInteger = 0;
            _oQuery.ParamByName("PRMenuEnabled").AsInteger = 0;
            _oQuery.Open();
        }

        /// <summary>
        /// Check whether the Compaign name exist or not
        /// </summary>
        /// <returns></returns>
        private bool CheckCampaignNameExist(string compaignName)
        {
            int existCompaignNumber;
            _oQuery.SQL = "JobService_checkCampaignNameExistsAdvertiser";
            _oQuery.ParamByName("advid").AsInteger = _advid;
            _oQuery.ParamByName("description").AsString = compaignName;
            _oQuery.Open();

            existCompaignNumber = _oQuery.FieldByName("numberOfCompaign").AsInteger;
            return existCompaignNumber > 0;
        }

        private void GetLocale(string filePath)
        {
            string[] cols;
            string line =PublicFunctionUtil.GetOneLineDataFromCSVFile(filePath);

            if (line == string.Empty)
            {
                _locale = "US";
                return;
            }

            if (PublicFunctionUtil.CountOccurrances(line, ",") >2)
            {
                char[] dilimiter = { ',' };
                cols = line.Split(dilimiter);
            }
            else
            {
                char[] dilimiter = { '\t' };
                cols = line.Split(dilimiter);
            }

            if (cols.Count() > 2)
            {
                _locale = cols.Count() > 5 ? cols[7] : cols[1];
            }
            else
            {
                _locale = "US";
            }
        }
        #endregion private methods
    }
}
