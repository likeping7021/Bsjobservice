﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using java.util.zip;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Public static functions utilities
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>05/05/2008</date>
    public static class PublicFunctionUtil
    {
        /// <summary>
        /// Check the CSV format
        /// </summary>
        /// <param name="strm"></param>
        /// <returns></returns>
        public static string GetFileEncoding(string srcFile)
        {
            // *** Use Default of Encoding.Default (Ansi CodePage)
            Encoding enc = Encoding.ASCII;

            // *** Detect byte order mark if any - otherwise assume default
            byte[] buffer = new byte[5];
            FileStream file = new FileStream(srcFile, FileMode.Open);
            long originalSize = file.Length;

            file.Read(buffer, 0, 5);
            file.Close();
            file.Dispose();

            if (originalSize == 0)
            {
                return "It is an empty file.";
            }

            if (buffer[0] == 0xef && buffer[1] == 0xbb && buffer[2] == 0xbf)
            {
                enc = Encoding.UTF8;
                return "UTF8";
            }

            else if (buffer[0] == 0xff && buffer[1] == 0xfe)
            {
                enc = Encoding.Unicode;
                return "UNICODE";
            }

            else if (buffer[0] == 0xfe && buffer[1] == 0xff)
            {
                enc = Encoding.UTF32;
                return "UTF32";
            }
            else if (buffer[0] == 0x2b && buffer[1] == 0x2f && buffer[2] == 0x76)
            {
                enc = Encoding.UTF7;
                return "UTF7";
            }

            return "ASCII";
        }

        /// <summary>
        /// Count the occurrance of one char in a line
        /// </summary>
        /// <param name="text"></param>
        /// <param name="findChar"></param>
        /// <returns></returns>
        public static int CountOccurrances(string line, string findChar)
        {
            int curPos = 0;
            int tempPos = 0;
            int count = 0;
            while (curPos >= 0)
            {
                curPos = line.IndexOf(findChar, tempPos);
                tempPos = curPos + 1;
                count++;
            }
            count--;
            return count;
        }

        /// <summary>
        /// Get one line from a file
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static string GetOneLineDataFromCSVFile(string filePath)
        {
            string line = string.Empty;
            using (StreamReader sw = new StreamReader(filePath))
            {
                if (!sw.EndOfStream)
                {
                    line = sw.ReadLine();
                }

                if (!sw.EndOfStream)
                {
                    line = sw.ReadLine();
                }
            }
            return line;
        }

        /// <summary>
        /// Copy directory from src folder to destination folder
        /// </summary>
        /// <param name="Src"></param>
        /// <param name="Dst"></param>
        public static void copyDirectory(string Src, string Dst)
        {
            String[] Files;

            if (Dst[Dst.Length - 1] != Path.DirectorySeparatorChar)
                Dst += Path.DirectorySeparatorChar;
            if (!Directory.Exists(Dst)) Directory.CreateDirectory(Dst);
            Files = Directory.GetFileSystemEntries(Src);
            foreach (string Element in Files)
            {
                // Sub directories
                if (Directory.Exists(Element))
                    copyDirectory(Element, Dst + Path.GetFileName(Element));
                // Files in directory
                else
                    File.Copy(Element, Dst + Path.GetFileName(Element), true);
            }
        }

        //Check the file size, make sure the file size is not over the maximum size.
        public static bool CheckFileSize(string fileName, long maximumFileSize)
        {
            long fileSize;
            FileInfo localFile = new FileInfo(@fileName);
            fileSize = localFile.Length;
            if (fileSize > maximumFileSize)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Clean the file after delivery 
        public static void Cleanfile(string fileName)
        {
            if (File.Exists(fileName))
            {
                CheckWriteLock(fileName);
                File.Delete(fileName);
            }
        }

        //Check the file if it is being locked
        public static void CheckWriteLock(string fullPath)
        {
            //loop until you can get a write lock on the file 
            while (true)
            {
                try
                {
                    using (FileStream fs = File.OpenWrite(fullPath))
                    {
                        System.Threading.Thread.Sleep(1000);
                    }
                    return;
                }
                catch (Exception) { }
            }
        }

        /// <summary>
        /// Zip the file for email attachement
        /// </summary>
        /// <Author>Keping Li</Author>
        /// <date>12/26/2007</date>
        public static void Zipfile(string fileName, string attachedZipFileName)
        {
            string[] fileNamesdForzip;
            fileNamesdForzip = new string[] { fileName };
            ZipFile zippedfile = ZipUtils.CreateEmptyZipFile(attachedZipFileName);
            zippedfile = ZipUtils.UpdateZipFile(zippedfile, null, fileNamesdForzip);
        }

        /// <summary>
        /// Zip the file for email attachement
        /// </summary>
        /// <Author>Keping Li</Author>
        /// <date>12/26/2007</date>
        public static void UnZipfile(string zippedFileName, string destinationFileName)
        {
            //Unzip the file 
            ZipFile zippedfile = new ZipFile(zippedFileName);
            ZipUtils.ExtractZipFile(zippedfile, destinationFileName);
        }

        public static void UnZipfiles(string zippedFileName, string destinationPath)
        {
            //Unzip the mutiple files
            ZipFile zippedfile = new ZipFile(zippedFileName);
            ZipUtils.ExtractZipFile(zippedfile, destinationPath, null);
        }

        /// <summary>
        /// Email ErrorCode information during the keyword sheet import and traffic process to the user
        /// </summary>
        /// <param name="trafficSheetFileName"></param>
        public static void EmailError(string errorMessage, string emailSmtp, string emailFrom, string emailTos, string emailCCs, string emailSubject, string placementSheetName, bool isBulkInsertError)
        {
            char[] seperator = { ';' };
            BSEmailJob emailError = new BSEmailJob();
            emailError.EmailSmtp = emailSmtp;
            emailError.EmailSubject = emailSubject;
            emailError.EmailFrom = emailFrom;
            emailError.EmailTos = emailTos;
            emailError.EmailCCs = emailCCs;

            if (isBulkInsertError)
            {
                //emailError.EmailMessage = "Attached is the error information during importing keywordSheet, placement Sheet Name:" + placementSheetName;
                emailError.EmailMessage = "Attached is the list of errors encountered during the upload process. Please review the errors and make your corrections to the file. Then you may re-upload the file.";
                emailError.EmailAttachmentFileNames = errorMessage;
                emailError.SendMailMessage(seperator, true);
            }
            else
            {
                if (placementSheetName == "")
                {
                    emailError.EmailMessage = errorMessage;
                }
                else
                {
                    emailError.EmailMessage = "An error occurred while processing your keyword sheet: " + placementSheetName;
                }
                emailError.SendMailMessage(seperator, false);
            }
        }

        //Get new date time after add days
        public static DateTime GetDateTime(string time, DateTime fiscalDate)
        {
            string[] t = time.Split(':');
            int hours = Convert.ToInt32(t[0]);
            int minutes = Convert.ToInt32(t[1]);
            return fiscalDate.AddHours(hours).AddMinutes(minutes);
        }

        /// <summary>
        /// Function to test whether the string is valid number or not.
        /// </summary>
        /// <param name="strNumber"></param>
        /// <returns></returns>
        public static bool IsNumber(string strNumber)
        {
            Regex objNotNumberPattern = new Regex("[^0-9.-]");
            Regex objTwoDotPattern = new Regex("[0-9]*[.][0-9]*[.][0-9]*");
            Regex objTwoMinusPattern = new Regex("[0-9]*[-][0-9]*[-][0-9]*");
            String strValidRealPattern = "^([-]|[.]|[-.]|[0-9])[0-9]*[.]*[0-9]+$";
            String strValidIntegerPattern = "^([-]|[0-9])[0-9]*$";
            Regex objNumberPattern = new Regex("(" + strValidRealPattern + ")|(" + strValidIntegerPattern + ")");

            return !objNotNumberPattern.IsMatch(strNumber) &&
                !objTwoDotPattern.IsMatch(strNumber) &&
                !objTwoMinusPattern.IsMatch(strNumber) &&
                objNumberPattern.IsMatch(strNumber);
        }

        public static bool IsAlphaNumeric(string strToCheck)
        {
            Regex objAlphaNumericPattern = new Regex("[^a-zA-Z0-9.-]");
            return !objAlphaNumericPattern.IsMatch(strToCheck);  
        }

        /// <summary>
        /// Convert a 32-bit number to a hex string with ls-byte 
        /// </summary>
        public static string Rhex(int num)
        {
            string str = string.Empty;
            string hex_chr = "0123456789abcdef";
            for (int j = 0; j <= 3; j++)
            {
                str += hex_chr.Substring(((num >> (j * 8 + 4)) & 0x0F),1) + hex_chr.Substring(((num >> (j * 8)) & 0x0F),1);
            }
            return str;
        }

        public static int[]  Str2blks_MD5(string str)
        {
	        int nblk = ((str.Length + 8) >> 6) + 1;
	        int[] blks = new int[nblk * 16];
            for (int i = 0; i < nblk * 16; i++)
            {
                blks[i] = 0;
            }
            for (int i = 0; i < str.Length; i++)
            {
               blks[i >> 2] |= ((Int32) Convert.ToChar(str.Substring(i,1))) << ((i % 4) * 8);
               blks[i >> 2] |= 0x80 << ((i % 4) * 8);
            }
	        blks[nblk * 16 - 2] = str.Length * 8;
	        return blks;
        }

        #region md5 functions, for create a token
        /// <summary>
        ///  * Add integers, wrapping at 2^32. This uses 16-bit operations internally to work around bugs in some JS interpreters.
        /// </summary>
        public static int Add(int x, int y)
        {
            int lsw = (x & 0xFFFF) + (y & 0xFFFF);
            int msw = (x >> 16) + (y >> 16) + (lsw >> 16);
            return (msw << 16) | (lsw & 0xFFFF);
        }

        /// <summary>
        /// Bitwise rotate a 32-bit number to the left
        /// </summary>
        public static int Rol(int num, int cnt)
        {
            return (num << cnt) | (num >> (32 - cnt));
        }

        public static int Cmn(int q, int a, int b, int x, int s, int t)
        {
            return Add(Rol(Add(Add(a, q), Add(x, t)), s), b);
        }

        public static int Ff(int a, int b, int c, int d, int x, int s, int t)
        {
            return Cmn((b & c) | ((~b) & d), a, b, x, s, t);
        }

        public static int Gg( int a, int b, int c, int d, int x, int s, int t)
        {
            return Cmn((b & d) | (c & (~d)), a, b, x, s, t);
        }

        public static int Hh( int a, int b, int c, int d, int x, int s, int t)
        {
            return Cmn(b ^ c ^ d, a, b, x, s, t);
        }

        public static int Ii(int a, int b, int c, int d, int x, int s, int t)
        {
            return Cmn(b ^ c ^ d, a, b, x, s, t);
        }

        public static string CalcMD5(string pstr)
        {
            int[] x = Str2blks_MD5(pstr);
            int a = 1732584193;
            int b = -271733879;
            int c = -1732584194;
            int d = 271733878;

            for (int i = 0; i < x.Length; i += 16)
            {
                int olda = a;
                int oldb = b;
                int oldc = c;
                int oldd = d;

                a = Ff(a, b, c, d, x[i + 0], 7, -680876936);
                d = Ff(d, a, b, c, x[i + 1], 12, -389564586);
                c = Ff(c, d, a, b, x[i + 2], 17, 606105819);
                b = Ff(b, c, d, a, x[i + 3], 22, -1044525330);
                a = Ff(a, b, c, d, x[i + 4], 7, -176418897);
                d = Ff(d, a, b, c, x[i + 5], 12, 1200080426);
                c = Ff(c, d, a, b, x[i + 6], 17, -1473231341);
                b = Ff(b, c, d, a, x[i + 7], 22, -45705983);
                a = Ff(a, b, c, d, x[i + 8], 7, 1770035416);
                d = Ff(d, a, b, c, x[i + 9], 12, -1958414417);
                c = Ff(c, d, a, b, x[i + 10], 17, -42063);
                b = Ff(b, c, d, a, x[i + 11], 22, -1990404162);
                a = Ff(a, b, c, d, x[i + 12], 7, 1804603682);
                d = Ff(d, a, b, c, x[i + 13], 12, -40341101);
                c = Ff(c, d, a, b, x[i + 14], 17, -1502002290);
                b = Ff(b, c, d, a, x[i + 15], 22, 1236535329);

                a = Gg(a, b, c, d, x[i + 1], 5, -165796510);
                d = Gg(d, a, b, c, x[i + 6], 9, -1069501632);
                c = Gg(c, d, a, b, x[i + 11], 14, 643717713);
                b = Gg(b, c, d, a, x[i + 0], 20, -373897302);
                a = Gg(a, b, c, d, x[i + 5], 5, -701558691);
                d = Gg(d, a, b, c, x[i + 10], 9, 38016083);
                c = Gg(c, d, a, b, x[i + 15], 14, -660478335);
                b = Gg(b, c, d, a, x[i + 4], 20, -405537848);
                a = Gg(a, b, c, d, x[i + 9], 5, 568446438);
                d = Gg(d, a, b, c, x[i + 14], 9, -1019803690);
                c = Gg(c, d, a, b, x[i + 3], 14, -187363961);
                b = Gg(b, c, d, a, x[i + 8], 20, 1163531501);
                a = Gg(a, b, c, d, x[i + 13], 5, -1444681467);
                d = Gg(d, a, b, c, x[i + 2], 9, -51403784);
                c = Gg(c, d, a, b, x[i + 7], 14, 1735328473);
                b = Gg(b, c, d, a, x[i + 12], 20, -1926607734);

                a = Hh(a, b, c, d, x[i + 5], 4, -378558);
                d = Hh(d, a, b, c, x[i + 8], 11, -2022574463);
                c = Hh(c, d, a, b, x[i + 11], 16, 1839030562);
                b = Hh(b, c, d, a, x[i + 14], 23, -35309556);
                a = Hh(a, b, c, d, x[i + 1], 4, -1530992060);
                d = Hh(d, a, b, c, x[i + 4], 11, 1272893353);
                c = Hh(c, d, a, b, x[i + 7], 16, -155497632);
                b = Hh(b, c, d, a, x[i + 10], 23, -1094730640);
                a = Hh(a, b, c, d, x[i + 13], 4, 681279174);
                d = Hh(d, a, b, c, x[i + 0], 11, -358537222);
                c = Hh(c, d, a, b, x[i + 3], 16, -722521979);
                b = Hh(b, c, d, a, x[i + 6], 23, 76029189);
                a = Hh(a, b, c, d, x[i + 9], 4, -640364487);
                d = Hh(d, a, b, c, x[i + 12], 11, -421815835);
                c = Hh(c, d, a, b, x[i + 15], 16, 530742520);
                b = Hh(b, c, d, a, x[i + 2], 23, -995338651);

                a = Ii(a, b, c, d, x[i + 0], 6, -198630844);
                d = Ii(d, a, b, c, x[i + 7], 10, 1126891415);
                c = Ii(c, d, a, b, x[i + 14], 15, -1416354905);
                b = Ii(b, c, d, a, x[i + 5], 21, -57434055);
                a = Ii(a, b, c, d, x[i + 12], 6, 1700485571);
                d = Ii(d, a, b, c, x[i + 3], 10, -1894986606);
                c = Ii(c, d, a, b, x[i + 10], 15, -1051523);
                b = Ii(b, c, d, a, x[i + 1], 21, -2054922799);
                a = Ii(a, b, c, d, x[i + 8], 6, 1873313359);
                d = Ii(d, a, b, c, x[i + 15], 10, -30611744);
                c = Ii(c, d, a, b, x[i + 6], 15, -1560198380);
                b = Ii(b, c, d, a, x[i + 13], 21, 1309151649);
                a = Ii(a, b, c, d, x[i + 4], 6, -145523070);
                d = Ii(d, a, b, c, x[i + 11], 10, -1120210379);
                c = Ii(c, d, a, b, x[i + 2], 15, 718787259);
                b = Ii(b, c, d, a, x[i + 9], 21, -343485551);

                a = Add(a, olda);
                b = Add(b, oldb);
                c = Add(c, oldc);
                d = Add(d, oldd);
            }

            return Rhex(a) + Rhex(b) + Rhex(c) + Rhex(d);
        }
        #endregion md5
    }
}
