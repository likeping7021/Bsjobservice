﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.AccessControl;
using System.Text.RegularExpressions;
using CHILKATFTPLib;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concreate an class to synchronous FTP download the keyword sheet from the client ftp site to bluestreak server.
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>06/11/2008</date>
     public class BSFTPFileSynchJob : BSJob
    {
        #region Private Data
        private string _ftpServer;
        private string _user;
        private string _ftppassword;
        private int _maxRetries = 5;
        private string _ftpPath;
        private string _fileMatch = string.Empty;
        private string _bsPath;  //Bluestreak server path
        private bool _ftpIncludeSubFolders = false;
        //private bool _bsUseSingleFolder;
        #endregion Private data

        #region public method
        /// <summary>
        /// Override the run() method, run FTP synchronous download job
        /// </summary>
        public override void Run()
        {
            int jobId = 0;
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSFTPFileSynchJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, FTP synchronous download started", _queueId, jobId), jobId);
                SetParameterValues();
                FTPSynDownload(jobId);
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, FTP synchronous download  compeleted successfully", _queueId, jobId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, FTP synchronous download failed with Error: {2}", _queueId, jobId, ex.Message), jobId, JobStatus.Failed);
                //throw ex;
                throw new Exception("We are experiencing connection errors. Please validate your FTP site and configuration settings are correct. Contact support@bluestreak.com if you need assistance. ;Connection Errors ftp site:  <" + _ftpServer + ">");
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetFTPJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                _ftpServer = _oQuery.FieldByName("HOST").AsString;
                _user = _oQuery.FieldByName("UserName").AsString;
                _ftppassword = _oQuery.FieldByName("Password").AsString;
                _ftpPath = _oQuery.FieldByName("Path").AsString;
                _bsPath = _oQuery.FieldByName("BlueStreakFilePath").AsString;
                _fileMatch = _oQuery.FieldByName("fileMatch").AsString;
            }
        }
        #endregion public method

        #region private method

        private void FTPSynDownload(int jobId)
        {
            int connectedTimes = 3;
            string initialSubfolder = string.Empty;
            ChilkatFTP ftp = new ChilkatFTP();
            ftp.Hostname = _ftpServer;
            ftp.Username = _user;
            ftp.Password = _ftppassword;
            ftp.Connect();

            bool success = ftp.IsConnected == 1 ? true : false;
            //Try to connect 3 times if connection fail
            while (!success && connectedTimes > 0)
            {
                ftp.Connect();
                connectedTimes--;
                success = ftp.IsConnected == 1 ? true : false;
                System.Threading.Thread.Sleep(5000);
            }

            if (success)
            {
                string message = string.Format("Retriving directory info for {0}", _ftpPath);
                this.LogMessage(jobId, message);
                //message = string.Format("Merging directory listings, remote path: {0}, local path: {1}", _ftpPath, _bsPath);
                //this.LogMessage(jobId, message);
                RunSyncFromFTPServer(ftp, _ftpPath, initialSubfolder, jobId);
            }
            else
            {
                throw new Exception("We are unable to connect to the ftp sever: " + _ftpServer + ". Please check the ftp server setting. ;The ftp sever: " + _ftpServer + " - Connection failed");
            }
        }

        /// <summary>
        /// Runs the file synch job
        /// </summary>
        /// <param name="ftp2"></param>
        /// <param name="ftpPath"></param>
        /// <param name="subfolder"></param>
        private void RunSyncFromFTPServer(ChilkatFTP ftp, string ftpPath, string subfolder, int jobId)
        {
            string message;
            int numbersOfFileAndDirs;
            bool writeExternalLog = false;

            //string curDir = ftp.GetCurrentRemoteDir();
            //ftp.ChangeRemoteDir(ftpPath.Substring(1));
            ftp.ChangeRemoteDir(ftpPath);
            numbersOfFileAndDirs = ftp.NumFilesAndDirs;

            bool ok;
            for (int i = 0; i <= numbersOfFileAndDirs - 1; i++)
            {
                ok = ftp.IsConnected == 1 ? true : false;
                //Check if the ftp is still connected after recursive
                if (ok)
                {
                    //If the file or dir be deleted during recursive
                    if ((object)ftp.GetFilename(i) == null)
                    {
                        continue;
                    }
                    string curFileOrDirName = ftp.GetFilename(i).Trim();
                    string localSubfolder = string.Empty;
                    bool isDirectory = ftp.GetIsDirectory(i) == 1 ? true : false;
                    if (isDirectory)
                    {
                        //If include subfolders, download subfolder, otherwise, skip sub-folder.
                        if (_ftpIncludeSubFolders )
                        {
                            string currentDir = ftp.GetCurrentRemoteDir();
                            localSubfolder = subfolder + "\\" + curFileOrDirName;
                            currentDir += "/" + curFileOrDirName + "/";
                            RunSyncFromFTPServer(ftp, currentDir, localSubfolder, jobId);

                            ftp.ChangeRemoteDir(ftpPath);
                        }
                    }
                    else
                    {
                        //only process files that match if _fileMatch is specified...
                        if (_fileMatch.Trim() != string.Empty)
                        {
                            if (!Regex.IsMatch(curFileOrDirName, _fileMatch))
                            {
                                continue;
                            }
                        }

                        //Use the file path to locate the file in the local root folder
                        //string localFilePath = _bsUseSingleFolder ? Path.Combine(_bsPath, curFileOrDirName) : Path.Combine(_bsPath,  _bsPath + subfolder + "\\" + curFileOrDirName);
                        string localFilePath = Path.Combine(_bsPath, curFileOrDirName);
                        FileInfo localFile = new FileInfo(localFilePath);

                        //If the file does not exist , or is smaller than the file on the FTP server, than download from the Client server
                        if (!localFile.Exists || (localFile.Length != ftp.GetSize(i)))
                        {
                            //if (!_bsUseSingleFolder)
                            //{
                            //    localFilePath = Path.Combine(_bsPath, _bsPath + subfolder);

                            //    //Make sure the local folder exists first ...
                            //    DirectoryInfo di = new DirectoryInfo(localFilePath);
                            //    if (!di.Exists)
                            //    {
                            //        Directory.CreateDirectory(localFilePath);
                            //    }
                            //    localFilePath = localFilePath + "\\" + curFileOrDirName;
                            //}

                            int errors = 0;
                            while (errors < _maxRetries)
                            {
                                try
                                {
                                    ok = ftp.GetFile(curFileOrDirName, localFilePath) == 1 ? true : false;
                                    if (ok)
                                    {
                                        message = string.Format("Ftp download {0} to {1}, {2} bytes", curFileOrDirName, localFilePath, ftp.GetSize(i));
                                        this.LogMessage(jobId, message);
                                        TransactionLog.log(string.Format("{0:MM/dd/yyy HH:mm:ss.fff}:{1}", DateTime.Now, message));

                                        errors = _maxRetries + 1;
                                        ftp.DeleteRemoteFile(curFileOrDirName);
                                        numbersOfFileAndDirs--;
                                    }
                                    else
                                    {
                                        throw new Exception(ftp.LastErrorText);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    errors++;
                                    message = string.Format("Error downloading {0} to {1}, {2}, retrying.", curFileOrDirName, localFilePath,ex.Message);
                                    this.LogMessage(jobId, message);
                                    TransactionLog.log(string.Format("{0:MM/dd/yyy HH:mm:ss.fff}:{1}", DateTime.Now, message));

                                    if (errors >= _maxRetries)
                                    {
                                        message = string.Format("Could not download {0} to {1}", curFileOrDirName, localFilePath, ex.Message);
                                        this.LogMessage(jobId, message);
                                        TransactionLog.log(string.Format("{0:MM/dd/yyy HH:mm:ss.fff}:{1}", DateTime.Now, message));
                                    }
                                    throw ex;
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion private method
    }
}
