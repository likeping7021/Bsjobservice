﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IonDBUtils;

namespace Bluestreak.BSJobService
{
    public enum JobStatus
    {
        Pending = 0,
        Running = 1,
        Successful = 2,
        Failed = 3,
        TrafficSheetDeleted = 4
    }

    public enum JobType
    {
        BSUploadDataFileJob = 1,
        BSKeywordTrafficProcessJob = 2,
        BSTrafficSheetGenerationJob = 3,
        BSEmailJob = 4,
        BSFileErrorCheckJob =5,
        BSFileWatcherJob = 6, //New Automation
        BSFTPFileSynchJob = 7, //New Automation
        BSFTPDeliveryJob =8,
        BSFileDeleteJob =9
    }

    /// <summary>
    /// Concreate an master job class, which is to run the sequence jobs for one Queue_id.  
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>05/23/2008</date>
    public class BSMasterJob
    {
        #region private member
        private SortedList<int, BSJob> _jobs;
        private int _queueId;
        private IonConnectionMgr _oConn;
        private IonQuery _oQuery;
        #endregion private memeber

        #region public method
        public BSMasterJob()
        {
            _jobs = new SortedList<int, BSJob>();
        }

        public void Dispose()
        {
            _oQuery.Close();
            _oQuery.Dispose();
            for (int i = 0; i < _jobs.Count; i++)
            {
                _jobs[_jobs.Keys[i]].Dispose();
            }
        }
        public void Initialize(int id, string dbTagInfo)
        {
            this._queueId = id;
            _oConn = new IonConnectionMgr();
            _oQuery = _oConn.GetAQueryByTagName(dbTagInfo);
            _oQuery.sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
        }

        public void Run()
        {
            try
            {
                this.LogStart(string.Format("Keyword uploading master job {0} starting", _queueId));

                for (int i = 0; i < _jobs.Count; i++)
                {
                    BSJob theJob = _jobs[_jobs.Keys[i]];
                    theJob.Run();
                    theJob.Dispose();
                }
                this.LogEnd(string.Format("Keyword uploading master job {0} compeleted successfully", _queueId), JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Keyword uploading master job {0} failed with Error: {1}", _queueId, ex.Message), JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        ///Retry again
        /// </summary>
        public bool RetryRun()
        {
            bool retryTimes;
            _oQuery.SQL = "JobService_RetryRun";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.Open();
            retryTimes = _oQuery.FieldByName("RetryTimes").AsInteger == 1 ? true : false;
            return retryTimes;
        }


        public void AddJob(int sequence, BSJob job)
        {
            _jobs.Add(sequence,job);
        }

        public BSJob Run_each_job_in_the_list
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }
        #endregion public method

        #region protected method

        /// <summary>
        ///Logs start of a scheduled job
        /// </summary>
        protected void LogStart(string message)
        {
            _oQuery.SQL = "JobService_BSMasterJobLogStart";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        /// <summary>
        ///Logs end of a scheduled job
        /// </summary>
        protected void LogEnd(string message, JobStatus jobStatus)
        {
            _oQuery.SQL = "JobService_BSMasterJobLogEnd";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.ParamByName("Status").AsInteger = Convert.ToInt32(jobStatus);
            _oQuery.Open();
        }
        #endregion protected method

        #region property
        public int ID
        {
            get
            {
                return _queueId;
            }
        }
        #endregion property
    }
}
