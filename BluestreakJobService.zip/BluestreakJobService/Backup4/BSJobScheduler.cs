﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IonDBUtils;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concreate an abatsract class, which will be inherited by subclass, this class will scheduler a master job in the Queue 
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>06/17/2008</date>
    public abstract class BSJobScheduler
    {        
        #region parameters
        /// Database Definition! 
        protected int _sheduleId;
        protected IonConnectionMgr _oConn;
        protected IonQuery _oQuery;
        #endregion parameters

        public event EventHandler Scheduled;

        public void Dispose()
        {
            _oQuery.Close();
            _oQuery.Dispose();
        }

        public void Initialize(string dbTagInfo, int sheduleId)
        {
            this._sheduleId = sheduleId;
            _oConn = new IonConnectionMgr();
            _oQuery = _oConn.GetAQueryByTagName(dbTagInfo);
            _oQuery.sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
        }

        protected void FireScheduled()
        {
            if (Scheduled != null)
            {
                Scheduled(this, new EventArgs());
            }
        }

        protected JobStatus GetCurrentJobStatus(int queueId)
        {
            _oQuery.SQL = "JobService_GetJobStatus";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = queueId;
            _oQuery.Open();

            return (JobStatus)_oQuery.FieldByName("Job_Status").AsInteger;
        }

        protected void LogStart(string message)
        {
            _oQuery.SQL = "JobService_BSScheduleLogStart";
            _oQuery.ParamByName("Job_schedule_id").AsInteger = _sheduleId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        protected void LogMessage(string message, int queueId)
        {
            _oQuery.SQL = "JobService_BSScheduleLogMessage";
            _oQuery.ParamByName("Job_schedule_id").AsInteger = _sheduleId;
            _oQuery.ParamByName("Job_queue_id").AsInteger = queueId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        /// <summary>
        ///Logs end of a scheduled job
        /// </summary>
        protected void LogEnd(string message, int queueId)
        {
            _oQuery.SQL = "JobService_BSScheduleLogEnd";
            _oQuery.ParamByName("Job_schedule_id").AsInteger = _sheduleId;
            _oQuery.ParamByName("Job_queue_id").AsInteger = queueId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        protected DateTime GetDateTime(string time, DateTime fiscalDate)
        {
            string[] t = time.Split(':');
            int hours = Convert.ToInt32(t[0]);
            int minutes = Convert.ToInt32(t[1]);
            return fiscalDate.AddHours(hours).AddMinutes(minutes);
        }

        public abstract void AddToSchedule();
        public abstract void SetScheduleParameter();
        public abstract void Run();
    }
}
