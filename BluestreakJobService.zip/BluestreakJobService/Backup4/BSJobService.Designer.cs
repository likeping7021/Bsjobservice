﻿namespace Bluestreak.BSJobService
{
    partial class BSJobService
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
            this.serverTimer = new System.Timers.Timer();
            ((System.ComponentModel.ISupportInitialize)(this.serverTimer)).BeginInit();
            // 
            // serverTimer
            // 
            this.serverTimer.Enabled = true;
            this.serverTimer.Interval = ((double)(configurationAppSettings.GetValue("Interval", typeof(double))));
            this.serverTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.serverTimer_Elapsed);
            // 
            // BSJobService
            // 
            this.ServiceName = "BlueStreak Job Service";
            ((System.ComponentModel.ISupportInitialize)(this.serverTimer)).EndInit();

        }

        /// <summary>
        /// The main entry point for process
        /// </summary>
        static void Main()
        {
            // More than one user Service may run within the same process. To add
            // another service to this process, change the following line to
            // create a second service object. For example,
            //
            //   ServicesToRun = New System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
            //
            System.ServiceProcess.ServiceBase[] ServicesToRun;
            ServicesToRun = new System.ServiceProcess.ServiceBase[] { new BSJobService() };
            System.ServiceProcess.ServiceBase.Run(ServicesToRun);
        }

        #endregion

        private System.Timers.Timer serverTimer;

    }
}
