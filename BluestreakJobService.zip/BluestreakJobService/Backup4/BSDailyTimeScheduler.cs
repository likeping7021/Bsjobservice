﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concreate an class to schedule daily run job.
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>06/23/2008</date>
    public class BSDailyTimeScheduler : BSJobScheduler
    {
        #region private member
        private int _queueId;
        private DateTime _nextJobSchedulerTime;
        #endregion private member

        #region public methods
        public override void Run()
        {
            try
            {
                this.LogStart(string.Format("Job schedule id: {0}, queue id: {1}, schedule job started", _sheduleId, _queueId));
                SetScheduleParameter();
                AddToSchedule();
                this.LogEnd(string.Format("Job schedule id: {0}, queue id: {1}, schedule job successfull", _sheduleId, _queueId), _sheduleId);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job schedule id: {0}, queue id: {1}, schedule job failed with Error: {2}", _sheduleId, _queueId, ex.Message), _sheduleId);
                throw ex;
            }
        }

        public override void AddToSchedule()
        {

            _oQuery.SQL = "JobService_ScheduleDailyJob";
            _oQuery.ParamByName("queueId").AsInteger = _queueId;
            _oQuery.ParamByName("NextScheduleTime").AsDateTime = _nextJobSchedulerTime.AddDays(1);
            _oQuery.Open();
        }

        public override void SetScheduleParameter()
        {
            _oQuery.SQL = "JobService_GetDailyJobParameterValue";
            _oQuery.ParamByName("sheduleId").AsInteger = _sheduleId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                _queueId = _oQuery.FieldByName("queueId").AsInteger;
                _nextJobSchedulerTime = _oQuery.FieldByName("NextJobSchedulerTime").AsDateTime;
            }
        }
        #endregion public methods
    }
}
