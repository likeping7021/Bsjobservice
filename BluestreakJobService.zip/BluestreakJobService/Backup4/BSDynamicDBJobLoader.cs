﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Configuration;
using IonDBUtils;

namespace Bluestreak.BSJobService
{
     /// <summary>
    /// Concrete a class to load a job schedule information 
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>04/25/2008</date>
    public class BSDynamicDBJobLoader
    {
        #region private member
        private int _id;
        private int _campaignId;
        private int _placementSheetId;
        private string _placementSheetName;
        private string _emailNotification = string.Empty;
        private string _emailNotificationTo = string.Empty;
        private string _emailNotificationCC = string.Empty;

        private int _scheduleId;
        private string _schedulerType;

        /// Database Definition! 
        private IonConnectionMgr _oConn;
        private IonQuery _oQuery;
        private string _dbTagInfo;
        public SortedList<int, string> _jobSequence;
        #endregion private member

        #region public method
        public BSDynamicDBJobLoader(string dbTagInfo)
        {
            this._dbTagInfo = dbTagInfo;
            _jobSequence = new SortedList<int, string>();

            _oConn = new IonConnectionMgr();
            _oQuery = _oConn.GetAQueryByTagName(_dbTagInfo);
            _oQuery.sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
        }

        /// <summary>
        /// load the the jon that need to be scheduled information
        /// </summary>
        /// <returns></returns>
        public bool GetNextJobNeedToSchedule()
        {
            bool hasJobNeedSchedule = false;
            try
            {
                lock (_oQuery)
                {
                    //First schedule all FTP and File watch jobs that need to be schedule
                    DateTime NextScheduleTime;
                    NextScheduleTime = PublicFunctionUtil.GetDateTime(ConfigurationSettings.AppSettings["schedulTtimeInterval"].ToString(), DateTime.Now);

                    _oQuery.SQL = "JobService_ScheduleFTPFileWatchJob";
                    _oQuery.ParamByName("Next_Job_schedulertime").AsDateTime = NextScheduleTime;
                    _oQuery.Open();

                    //get the next upload schedule job...
                    _oQuery.SQL = "JobService_GetJobsNeedToSchedule";
                    _oQuery.Open();

                    if (!_oQuery.EOF())
                    {
                        _scheduleId = _oQuery.FieldByName("scheduleId").AsInteger;
                        _schedulerType = _oQuery.FieldByName("schedulerType").AsString;
                        hasJobNeedSchedule = true;
                    }
                    else
                    {
                        hasJobNeedSchedule = false;
                    }
                }
            }
            catch (Exception ex)
            {
                TransactionLog.log("Can't get the next job information.", ex.ToString());
                //throw ex;
            }
            finally
            {
                _oQuery.Close();
                _oQuery.Dispose();
            }
            return hasJobNeedSchedule;
        }


        /// <summary>
        /// Load the scheduled job information
        /// </summary>
        public bool GetNextScheduledJobInfor()
        {
            bool hasNewJob = false;
            try
            {
                lock (_oQuery)
                {
                    _oQuery.SQL = "JobService_GetNextScheduledJobInfo";
                    _oQuery.Open();

                    if (!_oQuery.EOF())
                    {
                        _id = _oQuery.FieldByName("id").AsInteger;
                        _campaignId = _oQuery.FieldByName("campaign_id").AsInteger;
                        _placementSheetId = _oQuery.FieldByName("placementSheet_id").AsInteger;
                        _placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                        _emailNotification = _oQuery.FieldByName("Email_notification").AsString;
                        if (_emailNotification.IndexOf(";") > 0)
                        {
                            //More than one email address
                            _emailNotificationTo = _emailNotification.Substring(0, _emailNotification.IndexOf(";")).Trim();
                            _emailNotificationCC = _emailNotification.Substring(_emailNotificationTo.Length + 1,
                                _emailNotification.Length - _emailNotificationTo.Length - 1).Trim();
                        }
                        else
                        {
                            //Only one email address
                            _emailNotificationTo = _emailNotification.Trim();
                            _emailNotificationCC = "";
                        }
                        hasNewJob = true;
                    }
                    else
                    {
                        hasNewJob = false;
                    }

                    //Get the job sequence for the Queue (Master job)
                    if (hasNewJob)
                    {
                        _oQuery.SQL = "JobService_JobListSquence";
                        _oQuery.ParamByName("QueueId").AsInteger = this._id;
                        _oQuery.Open();

                        while (!_oQuery.EOF())
                        {
                            _jobSequence.Add(_oQuery.FieldByName("sequence").AsInteger, _oQuery.FieldByName("jobName").AsString.Trim());
                            _oQuery.Next();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TransactionLog.log("Can't get the next job information.", ex.ToString());
                //throw ex;
            }
            finally
            {
                _oQuery.Close();
                _oQuery.Dispose();
            }
            return hasNewJob;
        }

        #endregion 

        #region property
        public int ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public int SCHEDULEID
        {
            get
            {
                return _scheduleId;
            }
            set
            {
                _scheduleId = value;
            }
        }

        public string SCHEDULETYPE
        {
            get
            {
                return _schedulerType;
            }
            set
            {
                _schedulerType = value;
            }
        }

        public int CAMPAIGNID
        {
            get
            {
                return _campaignId;
            }
            set
            {
                _campaignId = value;
            }
        }

        public int PLACEMENTSHEETID
        {
            get
            {
                return _placementSheetId;
            }
            set
            {
                _placementSheetId = value;
            }
        }

        public string PLACEMENTSHEETNAME
        {
            get
            {
                return _placementSheetName;
            }
            set
            {
                _placementSheetName = value;
            }
        }

        public string EMAILNOTIFICATION
        {
            get
            {
                return _emailNotification;
            }
            set
            {
                _emailNotification = value;
            }
        }

        public string EMAILNOTIFICATIONTO
        {
            get
            {
                return _emailNotificationTo;
            }
            set
            {
                _emailNotificationTo = value;
            }
        }

        public string EMAILNOTIFICATIONCC
        {
            get
            {
                return _emailNotificationCC;
            }
            set
            {
                _emailNotificationCC = value;
            }
        }
        #endregion property
    }
}
