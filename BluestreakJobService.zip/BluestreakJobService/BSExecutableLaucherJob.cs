﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BluestreakJobService
{
    class BSExecutableLaucherJob : BSJob
    {
        public override void Run()
        {
            throw new NotImplementedException();
        }
    }
}
