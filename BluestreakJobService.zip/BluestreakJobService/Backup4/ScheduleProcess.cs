﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IonDBUtils;
using System.Configuration;

namespace Bluestreak.BSJobService
{
    public class ScheduleProcess
    {
        #region parameters
        //public delegate void JobFinished(object sender, EventArgs e);
        //public event JobFinished Finished;
 
        /// Database Definition! 
        private string _dbtag;
        private BSDynamicDBJobLoader _newJobschedule;
        #endregion parameters

        #region public methods
        /// <summary>
        /// Initialize the job information
        /// </summary>
        /// <param name="DB_TAG_INFO"></param>
        /// <param name="Jobschedule"></param>
        public void Initialize(string dbTagInfo, BSDynamicDBJobLoader Jobschedule)
        {
            this._dbtag = dbTagInfo;
            this._newJobschedule = new BSDynamicDBJobLoader(dbTagInfo);

            this._newJobschedule.SCHEDULEID = Jobschedule.SCHEDULEID;
            this._newJobschedule.SCHEDULETYPE = Jobschedule.SCHEDULETYPE;
        }

        public void Process()
        {
            //Finished(this, new EventArgs());
            string SMTP = ConfigurationSettings.AppSettings["SMTP"].ToString();
            string emailSender = ConfigurationSettings.AppSettings["EmailSender"].ToString();
            string emailTo = emailSender;

            int scheduleId = _newJobschedule.SCHEDULEID;
            string scheduleType = _newJobschedule.SCHEDULETYPE;

            TransactionLog.log("Begin to schedule job, Schedule ID: " + scheduleId + " to queue table");
            try
            {
                Type BSScheduleType = Type.GetType(scheduleType, true);
                var jobSheduled = (BSJobScheduler)Activator.CreateInstance(BSScheduleType);
                jobSheduled.Initialize(_dbtag, scheduleId);
                jobSheduled.Run();
                jobSheduled.Dispose();
            }
            catch (Exception ex)
            {
                PublicFunctionUtil.EmailError("Schedule job failed, Schedule ID: " + scheduleId, SMTP, emailSender, emailTo, "", "Schedule job failed", "", false);
                TransactionLog.log("Error to schedule job, Schedule ID: " + scheduleId + " to queue table" + ex.ToString());
            }
            TransactionLog.log("Finish to schedule job, Schedule ID: " + scheduleId + " to queue table");
        }

        public BSJobScheduler BSJobScheduler
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }

        #endregion public methods

        #region private methods
        /// <summary>
        /// Gets the corresponding DateTime for a given fiscal date and time string
        /// </summary>
        /// <param name="time"></param>
        /// <param name="fiscalDate"></param>
        /// <returns></returns>
        //private DateTime GetDateTime(string time, DateTime fiscalDate)
        //{
        //}
        #endregion private methods
    }
}
