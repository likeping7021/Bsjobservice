﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Configuration;

namespace Bluestreak.BSJobService
{    
    /// <summary>
    /// Concreate an class to schedule run job which has a special time_interval.
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>06/12/2008</date>
    public class BSTimeIntervalScheduler : BSJobScheduler
    {
        #region private member
        private int _advId;
        private int _OwnerUserId;
        private int _queueId = -99;
        private string _campaignName;
        private string _placementSheetName = string.Empty;
        private string _filePath;
        private string _Email_notification;
        private string _schedulTtimeInterval = string.Empty;
        private int _fileId;
        #endregion private member

        #region public methods

        /// <summary>
        /// Schedule Ftp, file watch and keyword upload job.
        /// </summary>
        /// <param name="isNewfile"></param>
        public override void Run()
        {
            try
            {
                this.LogStart(string.Format("Job schedule id: {0}, queue id: {1}, schedule job started", _sheduleId, _queueId));
                SetScheduleParameter();
                AddToSchedule();
                SetNextSchduleTime();
                this.LogEnd(string.Format("Job schedule id: {0}, queue id: {1}, schedule job successfull", _sheduleId, _queueId), _sheduleId);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job schedule id: {0}, queue id: {1}, schedule job failed with Error: {2}", _sheduleId, _queueId, ex.Message), _sheduleId);
                throw ex;
            }
        }

        /// <summary>
        /// Add a scheduled job to queue
        /// </summary>
        /// <param name="isNewFiscalDay"></param>
        /// <param name="fiscalDate"></param>
        public override void AddToSchedule()
        {
            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job begin to add the schedule to Queue table", _sheduleId, _queueId), _sheduleId);
            _oQuery.SQL = "JobService_ScheduleNewJob";
            _oQuery.ParamByName("scheduleId").AsInteger = _sheduleId;
            _oQuery.ParamByName("Adv_id").AsInteger = _advId;
            _oQuery.ParamByName("Owner_User_id").AsInteger = _OwnerUserId;
            _oQuery.ParamByName("campaignName").AsString = _campaignName;
            _oQuery.ParamByName("placementSheetName").AsString = _placementSheetName;
            _oQuery.ParamByName("Email_notification").AsString = _Email_notification;
            _oQuery.ParamByName("filePath").AsString = _filePath;
            _oQuery.ParamByName("tsvFilePath").AsString = Path.GetDirectoryName(_filePath) +"\\cleanFiles\\" + Path.GetFileNameWithoutExtension(_filePath)+ ".tsv";
            _oQuery.ParamByName("fileId").AsInteger = _fileId;
            _oQuery.Open();

            //Record in the schedule histroy detail table
            if (!_oQuery.EOF())
            {
                _queueId = _oQuery.FieldByName("queue_id").AsInteger;
            }

            _oQuery.SQL = "JobService_BSScheduleDetail";
            _oQuery.ParamByName("Job_schedule_id").AsInteger = _sheduleId;
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Note").AsString = "Schedule ID:" + _sheduleId + " has been scheduled a job to run as Queue Id: " + _queueId;
            _oQuery.Open();

            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job add the schedule to Queue table completely", _sheduleId, _queueId), _sheduleId);
        }

        /// <summary>
        /// Set the shedule job parameters
        /// </summary>
        public override void SetScheduleParameter()
        {
            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job begin to set parameters' value", _sheduleId, _queueId), _sheduleId);
            _oQuery.SQL = "JobService_GetScheduleParameterValues";
            _oQuery.ParamByName("ScheduleId").AsInteger = _sheduleId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                string fileName = string.Empty;
                _advId = _oQuery.FieldByName("Adv_id").AsInteger;
                _OwnerUserId = _oQuery.FieldByName("Owner_User_id").AsInteger;
                _filePath = _oQuery.FieldByName("fileName").AsString;
                _fileId = _oQuery.FieldByName("fileId").AsInteger;
                _Email_notification = _oQuery.FieldByName("Email_notification").AsString;
                fileName = Path.GetFileName(_filePath);
                _campaignName = fileName.Substring(0, fileName.IndexOf("_"));
                fileName = fileName.Substring(fileName.IndexOf("_") + 1);

                if (fileName.IndexOf("_") > 0)
                {
                    _placementSheetName = fileName.Substring(0, fileName.IndexOf("_"));
                }
            }

            _schedulTtimeInterval = ConfigurationSettings.AppSettings["schedulTtimeInterval"].ToString();
            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job set parameters' value completed", _sheduleId, _queueId), _sheduleId);

        }
        #endregion public methods

        #region private methods
        /// <summary>
        /// Reset the next schedule time for the schedule id
        /// </summary>
        private void SetNextSchduleTime()
        {
            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job begin to set next schedule time", _sheduleId, _queueId), _sheduleId);

            DateTime NextScheduleTime;
            NextScheduleTime = GetDateTime(_schedulTtimeInterval, DateTime.Now);

            _oQuery.SQL = "JobService_SetNextScheduleTime";
            _oQuery.ParamByName("ScheduleId").AsInteger = _sheduleId;
            _oQuery.ParamByName("Next_Job_schedulertime").AsDateTime = NextScheduleTime;
            _oQuery.Open();

            this.LogMessage(string.Format("Job schedule id: {0}, queue id: {1}, schedule job set next schedule time completely", _sheduleId, _queueId), _sheduleId);
        }
        #endregion private methods
    }
}
