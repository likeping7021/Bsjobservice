﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Configuration;


namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concrete a job class for file watch to see if the file exist (new, old or not exist)
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>06/17/2008</date>
    public partial class BSFileWatcherJob : BSJob
    {
        #region private data
        private int _searchIntervalInSeconds;
        private string _BlueStreakFilePath;
        private string _fileMatch = string.Empty;
        private string _lookbackDuration = string.Empty;
        private string _shortName;
        private int _advid;
        private string _advname;
        private string _locale = "US";

        private FileSystemWatcher _watcher;
        private RegisteredWaitHandle _waitHandle;
        private AutoResetEvent _fileCreatedAndOverwrittenEvent;
        private AutoResetEvent _signalCompleteEvent;
        #endregion provate data

        #region private class
        /// <summary>
        /// Private class used to handle inter-thread communication 
        /// </summary>
        private class WaitInfo
        {
            private RegisteredWaitHandle _handle;
            private bool _timeOut;

            public WaitInfo()
            {
                _handle = null;
                _timeOut = false;
            }

            public RegisteredWaitHandle Handle
            {
                get { return _handle; }
                set { _handle = value; }
            }

            public bool TimeOut
            {
                get { return _timeOut; }
                set { _timeOut = value; }
            }
        }
        #endregion private class

        #region public method
        public enum ExistFileCode
        {
            NewFile = 0,
            OldFile = 1,
            Notexist = 2
        }

        public BSFileWatcherJob()
        {
            _watcher = new FileSystemWatcher();
            _fileCreatedAndOverwrittenEvent = new AutoResetEvent(false);
            _signalCompleteEvent = new AutoResetEvent(false);
        }
        /// <summary>
        /// Override the run() method, run File watcher job
        /// </summary>
        public override void Run()
        {
            int waitTryTimes = 3;
            JobStatus FtpSynJobStatus = JobStatus.Running;
            int jobId = 0;
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSFileWatcherJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, File watching started", _queueId, jobId), jobId);
                SetParameterValues();
                WatchFile(jobId);
                
                while ((FtpSynJobStatus == JobStatus.Pending || FtpSynJobStatus == JobStatus.Running))// && waitTryTimes > 0)
                {
                    FtpSynJobStatus = CheckFTPSynJobStatus();
                    System.Threading.Thread.Sleep(10000);
                    //waitTryTimes--;
                }

                UpdateScheduleForNewFile(jobId);

                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, File watching compeleted successfully", _queueId, jobId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, File watching failed with Error: {3}", _queueId, jobId, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetScheduleJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                _BlueStreakFilePath = _oQuery.FieldByName("BlueStreakFilePath").AsString;
                _fileMatch = _oQuery.FieldByName("fileMatch").AsString;
                _advid = _oQuery.FieldByName("Adv_id").AsInteger;
                _advname = _oQuery.FieldByName("advertiser").AsString;
                _searchIntervalInSeconds = Convert.ToInt32(ConfigurationSettings.AppSettings["searchIntervalInSeconds"].ToString());
                _lookbackDuration = ConfigurationSettings.AppSettings["lookbackDuration"].ToString();
            }
        }
        #endregion public method

        #region Event Handlers
        /// <summary>
        /// Implement an event for file overwritten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void watcher_CreatedOrOverwritten(object sender, FileSystemEventArgs e)
        {
            //If we get a file that matches our matching patterns, raise the signal...
            _fileMatch = _fileMatch.Trim();
            if (_fileMatch != string.Empty)
            {
                if (!Regex.IsMatch(e.Name, _fileMatch))
                {
                    return;
                }
            }

            //This handles the case where a large file is being created. we don't want to raise the signal until all the data is there...
            PublicFunctionUtil.CheckWriteLock(e.FullPath);
            this.LogMessage(_queueId, string.Format("File {0} was found", e.FullPath));
            _fileCreatedAndOverwrittenEvent.Set();
        }
        #endregion Event Handler

        #region private methods
        /// <summary>
        /// Open the file watcher to check whether the file reaches
        /// </summary>
        /// <param name="jobId"></param>
        private void WatchFile(int jobId)
        {
            string fileFullPath = string.Empty;
            ExistFileCode FileExistCode;

            FileExistCode = CheckFileExist(_lookbackDuration, ref fileFullPath);
            if (FileExistCode == ExistFileCode.NewFile)
            {
                PublicFunctionUtil.CheckWriteLock(fileFullPath);
                this.LogEnd(string.Format("Job {0} completed successfully", jobId), jobId, JobStatus.Successful);
            }
            else
            {
                _watcher.Path = _BlueStreakFilePath;
                _watcher.Changed += new FileSystemEventHandler(watcher_CreatedOrOverwritten);
                _watcher.Created += new FileSystemEventHandler(watcher_CreatedOrOverwritten);

                WaitInfo wi0 = new WaitInfo();
                wi0.Handle = ThreadPool.RegisterWaitForSingleObject(_fileCreatedAndOverwrittenEvent, new WaitOrTimerCallback(FileCreatedCallback), wi0, _searchIntervalInSeconds * 1000, true);
                WaitInfo wi1 = new WaitInfo();
                wi1.Handle = ThreadPool.RegisterWaitForSingleObject(_signalCompleteEvent, new WaitOrTimerCallback(SignalCompleteCallback), wi1, -1, true);

                //Enable the File SystemWatcher to receive events...
                _watcher.EnableRaisingEvents = true;

                //Wait here for a signal....
                _signalCompleteEvent.WaitOne();

                _watcher.Dispose();

                //At this point, either a macthing file has been overwritten in the _sourcePPath folder, or we have reached the timeout, 
                if (wi0.TimeOut)
                {
                    if (FileExistCode == ExistFileCode.Notexist)
                    {
                        //Log no new file if _raiseErrorOntimeout is true; otherwise, log a warning...
                        string message = string.Format("BSJobFileWatcher timeout after {0} seconds. No new file coming", _searchIntervalInSeconds);
                        //this.LogEnd(string.Format("Job {0} completed, {1}", jobId, message), jobId, JobStatus.Successful);
                    }
                    else //this is old file
                    {
                        this.LogMessage(jobId, string.Format("Job {0} completed with warning : There is only an old file.", jobId));
                    }
                }
                else
                {
                    this.LogMessage(jobId, string.Format("Job {0} completed sucessfully", jobId));
                }
            }
        }

        /// <summary>
        /// Implement a method for file created call back function
        /// </summary>
        /// <param name="state"></param>
        /// <param name="timeOut"></param>
        private void FileCreatedCallback(object state, bool timeOut)
        {
            //Set the TimeOut property of the wait handle object based on whether we wewe called because of a timeout or not...
            ((WaitInfo)state).TimeOut = timeOut;
            _signalCompleteEvent.Set();
        }

        private void SignalCompleteCallback(object state, bool timeOut)
        {
            _signalCompleteEvent.Set();
        }

        private ExistFileCode CheckFileExist(string lookbacktime, ref string fullPath)
        {
            bool fileExist = false;
            DirectoryInfo dir = new DirectoryInfo(_BlueStreakFilePath);
            FileInfo[] Files = dir.GetFiles();
            foreach (FileInfo file in Files)
            {
                _fileMatch = _fileMatch.Trim();
                if (_fileMatch != string.Empty)
                {
                    DateTime DteCompareTime = ComparedDate(file, lookbacktime);
                    if (Regex.IsMatch(file.Name, _fileMatch) && DteCompareTime > DateTime.Now)
                    {
                        fullPath = @_BlueStreakFilePath + "\\" + file.Name;
                        fileExist = true;
                        break;
                    }
                }
            }

            if (fileExist)
            {
                FileInfo fileMembers = new FileInfo(@fullPath);
                DateTime DteCompareTime = ComparedDate(fileMembers, lookbacktime);

                return DteCompareTime > DateTime.Now ? ExistFileCode.NewFile : ExistFileCode.OldFile;
            }
            else
            {
                return ExistFileCode.Notexist;
            }
        }
        #endregion private methods
    }
}
