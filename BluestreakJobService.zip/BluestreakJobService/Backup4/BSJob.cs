﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IonDBUtils;

namespace Bluestreak.BSJobService
{       
    /// <summary>
    /// Concreate an abatsract class, which will be inherited by subclass, this class will be used as bluestreak schedule parent job type, 
    /// such as keywordsheet upload job type, ftp job type, email job type, launch executable job type, etc...
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <date>05/08/2008</date>
    public abstract class BSJob
    {
        #region Protected Data
        protected int _queueId;
        protected IonConnectionMgr _oConn;
        protected IonQuery _oQuery;
        #endregion Protected Data

        #region public method
        public enum CSVFormat
        {
            Ascii = 0,
            UTF16 = 1
        }

        public void Dispose()
        {
            _oQuery.Close();
            _oQuery.Dispose();
        }

        public void Initialize(int id, string dbTagInfo)
        {
            this._queueId = id;
            _oConn = new IonConnectionMgr();
            _oQuery = _oConn.GetAQueryByTagName(dbTagInfo);
            _oQuery.sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
        }

        public abstract void Run();
        public abstract void SetParameterValues();
        #endregion

        #region protected method
        /// <summary>
        ///Logs start of a scheduled job
        /// </summary>
        protected void LogStart(string message, int jobId)
        {
            _oQuery.SQL = "JobService_BSJobLogStart";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Job_id").AsInteger = jobId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        /// <summary>
        ///Logs a free-form message other than job start or job end
        /// </summary>

        protected void LogMessage(int jobId, string message)
        {
            _oQuery.SQL = "JobService_BSJobLogMessage";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Job_id").AsInteger = jobId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.Open();
        }

        /// <summary>
        ///Logs end of a scheduled job
        /// </summary>
        protected void LogEnd(string message, int jobId, JobStatus jobStatus)
        {
            _oQuery.SQL = "JobService_BSJobLogEnd";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("Job_id").AsInteger = jobId;
            _oQuery.ParamByName("Message").AsString = message;
            _oQuery.ParamByName("Status").AsInteger = Convert.ToInt32(jobStatus);
            _oQuery.Open();
        }

        /// <summary>
        /// Get the current job id
        /// </summary>
        /// <param name="queueId"></param>
        /// <param name="jobName"></param>
        /// <returns></returns>
        protected int GetJobId(int queueId, JobType jobType)
        {
            int jobId = 0;
            _oQuery.SQL = "JobService_GetJobId";
            _oQuery.ParamByName("Queue_id").AsInteger = queueId;
            _oQuery.ParamByName("jobType").AsInteger = Convert.ToInt32(jobType);
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                jobId = _oQuery.FieldByName("jobId").AsInteger;
            }
            return jobId;
        }
        #endregion protected method
    }
}
