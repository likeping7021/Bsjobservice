﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Summary description for TransLogObject.
    ///		The class to write a log file on hard drive. 
    /// </summary>
    /// 

    public class TransactionLog
    {
        public static void log(string message)
        {
            try
            {
                string LogFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();
                string DEBUG_FILE_NAME = LogFilePath + "\\LOG\\JobServicelog" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";
                using (StreamWriter sw = new StreamWriter(DEBUG_FILE_NAME, true))
                {
                    sw.WriteLine(DateTime.Now + " : " + message);
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
            }
        }

        public static void log(string message, string error)
        {
            try
            {
                string LogFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();
                string DEBUG_FILE_NAME = LogFilePath + "\\LOG\\JobServicelog" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";
                using (StreamWriter sw = new StreamWriter(DEBUG_FILE_NAME, true))
                {
                    sw.WriteLine(DateTime.Now + " : " + message);
                    sw.WriteLine(error);
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.ToString());
            }
        }

        public static void Error(string lineNumber, string error, string campaignid, string placementSheetId, string placementSheetName)
        {
            try
            {
                string ErrorFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();
                string ERROR_FILE_NAME = ErrorFilePath + "\\Error\\JobServiceError_" + campaignid + "_" + placementSheetId + " _" +
                    placementSheetName + "_" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";
                using (StreamWriter sw = new StreamWriter(ERROR_FILE_NAME, true))
                {
                    sw.WriteLine("Line " + lineNumber + " : " + error);
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }
        }
    }
}
