﻿using System;
using System.ComponentModel;
using System.Linq;
using System.ServiceProcess;
using System.Collections;
using System.Threading;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concrete a window service for upload Keyword sheet and generate traffic sheet
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>04/25/2008</date>
    public partial class BSJobService : ServiceBase
    {
        private ArrayList jobList;
        private ArrayList jobListFtpFileWatcher;
        public BSJobService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            serverTimer.Enabled = true;
        }

        protected override void OnStop()
        {
            serverTimer.Enabled = false;
        }

        private void serverTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            serverTimer.Stop();
            jobList = new ArrayList();
            jobListFtpFileWatcher = new ArrayList();
            this.run();
            serverTimer.Start();
        }

        public void run()
        {
            string databaseTagName = string.Empty;
            int maxThreads;
            bool hasScheduledJob = false;
            bool hasJobNeedToSchedule = false;

            //Get System properties
            System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
            databaseTagName = ((System.String)(configurationAppSettings.GetValue("DATABASEINFO", typeof(System.String))));
            maxThreads = ((System.Int32)(configurationAppSettings.GetValue("MAXTHREAD", typeof(System.Int32))));

            //Schedule job to queue table
            do
            {
                BSDynamicDBJobLoader newJobschedule = new BSDynamicDBJobLoader(databaseTagName);
                hasScheduledJob = newJobschedule.GetNextJobNeedToSchedule();
                if (hasScheduledJob)
                {
                    ScheduleProcess ScheduleObj = new ScheduleProcess();
                    ScheduleObj.Initialize(databaseTagName, newJobschedule);
                    Thread scheduleRunner = new Thread(new ThreadStart(ScheduleObj.Process));
                    scheduleRunner.Start();
                }
                Thread.Sleep(1000);
            } while (hasJobNeedToSchedule);

            ////Run the job pending in the queue table
            do
            {
                BSDynamicDBJobLoader newJobschedule = new BSDynamicDBJobLoader(databaseTagName);
                hasScheduledJob = newJobschedule.GetNextScheduledJobInfor();

                if (jobList.Count < maxThreads && hasScheduledJob)
                {
                    if (newJobschedule.CAMPAIGNID == -99 || newJobschedule.CAMPAIGNID == -999)
                    {
                        JobProcess jobObjFtpFileWatcher = new JobProcess();
                        jobListFtpFileWatcher.Add(jobObjFtpFileWatcher);
                        jobObjFtpFileWatcher.Initialize(databaseTagName, newJobschedule);
                        jobObjFtpFileWatcher.Finished += new JobProcess.JobFinished(JobProcessFinishedHandler);
                        Thread jobRunnerFtpFileWatcher = new Thread(new ThreadStart(jobObjFtpFileWatcher.Process));
                        jobRunnerFtpFileWatcher.Start();
                    }
                    else
                    {
                        JobProcess jobObj = new JobProcess();
                        jobList.Add(jobObj);
                        jobObj.Initialize(databaseTagName, newJobschedule);
                        jobObj.Finished += new JobProcess.JobFinished(JobProcessFinishedHandler);
                        Thread jobRunner = new Thread(new ThreadStart(jobObj.Process));
                        jobRunner.Start();
                    }
                    Thread.Sleep(12000);
                }
                
            } while (hasScheduledJob);
        }

        protected void JobProcessFinishedHandler(object sender, EventArgs e)
        {
            JobProcess JobObj = (JobProcess)sender;

            try
            {
                jobList.Remove(JobObj);
            }
            catch(Exception ex)
            {
                TransactionLog.log("Error to finish the keyword upload and traffic process. " + ex.Message.ToString());
            }
        }

        public JobProcess JobProcess_multithread
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }

        public BSDynamicDBJobLoader BSDynamicDBJobLoader
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }

        public ScheduleProcess ScheduleProcess
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }
    }
}
