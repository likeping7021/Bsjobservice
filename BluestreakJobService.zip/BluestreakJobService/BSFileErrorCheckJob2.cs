﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using IonDBUtils;

namespace Bluestreak.BSJobService
{
    public partial class BSFileErrorCheckJob : BSJob
    {
        //#region private methods
        ///// <summary>
        ///// Check the whether the name is valid
        ///// </summary>
        ///// <param name="name"></param>
        ///// <returns></returns>
        //private bool isNameValid(string name)
        //{
        //    string currentChar = string.Empty;
        //    int charIndex = 0;
        //    bool bStillValid = true;

        //    //isNameValid = true
        //    while (charIndex < name.Length && bStillValid == true)
        //    {
        //        currentChar = name.Substring(charIndex, 1);

        //        if (!((name.CompareTo("a") >= 0 && name.CompareTo("z") <= 0) || (name.CompareTo("A") >= 0 && name.CompareTo("Z") <= 0)
        //            || PublicFunctionUtil.IsNumber(currentChar) || currentChar == "-" || currentChar == "'"))
        //        {
        //            bStillValid = false;
        //        }

        //        charIndex++;
        //    }
        //    return bStillValid;
        //}

        ///// <summary>
        /////This function is to check Row content errors
        ///// </summary>
        ///// <param name="tableName"></param>
        ///// <returns></returns>
        //private bool CheckRowAndHandleErrors(int rowIndex)
        //{
        //    bool bAtLeastOneError = false;

        //    bAtLeastOneError = CheckLengthAndHandleErrors(_publisherName, "Publisher Name", 64, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_placementName, "Placement Name", 64, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckNameAndHandleErrors(_placementName, "Placement Name", rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_creativeName, "Creative Name", 255, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckNameAndHandleErrors(_creativeName, "Creative Name", rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_headline, "Headline", 200, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_description1, "Description Line 1", 200, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_description2, "Description Line 2", 200, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_displayURL, "Display URL", 200, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_locale, "Geographic Location", 32, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_keyword, "Keyword", 200, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckLengthAndHandleErrors(_clickURL, "Click URL", 2048, rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckUrlAndHandleErrors(_clickURL, "Click URL", rowIndex, _campaignId, _placementSheetId) ||
        //                        CheckMaxCpcAndHandleErrors(_maxCPC, rowIndex, _campaignId, _placementSheetId);

        //    return bAtLeastOneError;
        //}

        ///// <summary>
        ///// This function checks names against rules applied to the ionad objects Placement and Creative Returns a boolean indicating the 
        ///// presence of at least one error
        ///// </summary>
        ///// <param name="columnValue"></param>
        ///// <param name="columnName"></param>
        ///// <param name="rowIndex"></param>
        ///// <param name="campaignid"></param>
        ///// <param name="placementSheetId"></param>
        ///// <returns></returns>
        //private bool CheckNameAndHandleErrors(string columnValue, string columnName, int rowIndex, int campaignid, int placementSheetId)
        //{
        //    bool bError = false;

        //    if (columnValue.Length > 0)
        //    {
        //        if (PublicFunctionUtil.IsNumber(columnValue))
        //        {
        //            WriteErrors(rowIndex, columnName + " field cannot be a number", campaignid, placementSheetId, _placementSheetName);
        //            bError = true;
        //        }
        //        else if (columnValue.Length == 1)
        //        {
        //            WriteErrors(rowIndex, columnName + " field must be at least two characters", campaignid, placementSheetId, _placementSheetName);
        //            bError = true;
        //        }
        //        else if (!isNameValid(columnValue))
        //        {
        //            WriteErrors(rowIndex, columnName + " field contains invalid characters.  Letters, numbers," +
        //            "and hyphens are the only characters allowed in this field", campaignid, placementSheetId, _placementSheetName);
        //            bError = true;
        //        }
        //    }
        //    return bError;
        //}

        ///// <summary>
        ///// Returns a boolean indicating the presence of an error
        ///// </summary>
        ///// <param name="?"></param>
        ///// <param name="?"></param>
        ///// <param name="?"></param>
        ///// <returns></returns>
        //private bool CheckUrlAndHandleErrors(string url, string columnName, int rowIndex, int campaignid, int placementSheetId)
        //{
        //    bool bError = false;

        //    if (url != "" && !PublicFunctionUtil.isUrlValid(url))
        //    {
        //        bError = true;
        //        WriteErrors(rowIndex, columnName + " field contains an invalid URL", campaignid, placementSheetId, _placementSheetName);
        //    }

        //    return bError;
        //}

        ///// <summary>
        /////This function is to check the lenght errors
        ///// </summary>
        ///// <param name="tableName"></param>
        ///// <returns></returns>
        //private bool CheckLengthAndHandleErrors(string columnValue, string columnName, int maxLength, int rowIndex, int campaignid, int placementSheetId)
        //{
        //    bool bError = false;

        //    if (columnValue.Length > maxLength)
        //    {
        //        bError = true;
        //        WriteErrors(rowIndex, columnName + " field exceeds maximum length of " + maxLength.ToString() + " characters", campaignid, placementSheetId, _placementSheetName);
        //    }

        //    return bError;
        //}

        ///// <summary>
        ///// Check the MaxCpc is valid or not, Max CPC must be NULL or :	0 < MaxCPC < 100,000,000
        ///// </summary>
        ///// <param name="maxCPC"></param>
        ///// <param name="rowIndex"></param>
        ///// <returns></returns>
        //private bool CheckMaxCpcAndHandleErrors(double maxCPC, int rowIndex, int campaignid, int placementSheetId)
        //{
        //    bool bError = false;
        //    string errorDescription = "Max CPC must be a number greater than zero and less than one hundred million (100,000,000)";

        //    if (maxCPC.ToString().Length > 0)
        //    {
        //        if (!(PublicFunctionUtil.IsNumber(maxCPC.ToString())))
        //        {
        //            WriteErrors(rowIndex, errorDescription, campaignid, placementSheetId, _placementSheetName);
        //            bError = true;
        //        }
        //        else
        //        {
        //            if (maxCPC <= 0 || maxCPC >= 100000000)
        //            {
        //                WriteErrors(rowIndex, errorDescription, campaignid, placementSheetId, _placementSheetName);
        //                bError = true;
        //            }
        //        }
        //    }

        //    return bError;
        //}

        ///// <summary>
        ///// Check the Publisher value errors
        ///// </summary>
        //private void CheckPublisher(int rowIndex, ref Dictionary<string, int> publisherDictionary, bool no_rule_check)
        //{
        //    string errorDescription = string.Empty;
        //    if (!publisherDictionary.ContainsKey(_publisherName))
        //    {
        //        publisherDictionary.Add(_publisherName, 0);
        //        if (!no_rule_check)
        //        {
        //            if (publisherDictionary.Count > _RULE_Max_Publishers_Per_Sheet)
        //            {
        //                if (_RULE_Max_Publishers_Per_Sheet == 1)
        //                {
        //                    errorDescription = "There can only be one Publisher per Keyword Sheet ";
        //                }
        //                else
        //                {
        //                    errorDescription = "There can only be maximum of " + _RULE_Max_Publishers_Per_Sheet + " Publishers per Keyword Sheet.";
        //                }
        //                WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //            }
        //        }
        //    }
        //}

        ///// <summary>
        ///// Check the placement value errors
        ///// </summary>
        //private void CheckPlacement(int rowIndex, ref Dictionary<string, string[]> placementDictionary, ref Dictionary<string, int> publisherDictionary, string[] placementNameValue, ref string[] placementAttributes, bool no_rule_check)
        //{
        //    string errorDescription = string.Empty;
        //    if (placementDictionary.ContainsKey(_placementName))
        //    {
        //        if (placementNameValue[1] != _publisherName)
        //        {
        //            errorDescription = "Publisher '" + _publisherName + "' contradicts line " + placementNameValue[0] +
        //                                 " where Placement '" + _placementName + "' was listed with Publisher '" + placementNameValue[1] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }

        //        if (placementNameValue[2] != _locale)
        //        {
        //            errorDescription = "Geographic location '" + _locale + "' contradicts line " + placementNameValue[0] +
        //                                 " where Placement '" + _placementName + "' was listed with Geographic Location '" + placementNameValue[2] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }
        //    }
        //    else
        //    {
        //        placementAttributes[0] = rowIndex.ToString();
        //        placementAttributes[1] = _publisherName;
        //        placementAttributes[2] = _locale;
        //        placementAttributes[3] = "0"; //number of creatives per placement/site
        //        placementDictionary.Add(_placementName, placementAttributes);
        //        publisherDictionary[_publisherName] = publisherDictionary[_publisherName] + 1;

        //        if (!no_rule_check)
        //        {
        //            if (publisherDictionary.Count > _RULE_Max_Placements_Per_Publisher)
        //            {
        //                errorDescription = "There can only be one Placement per Publisher.";
        //            }
        //            else
        //            {
        //                errorDescription = "There can only be a maximum of " + _RULE_Max_Placements_Per_Publisher + " Placements per Publisher.";
        //            }
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }
        //    }

        //}

        ///// <summary>
        ///// Check the creative value errors
        ///// </summary>
        //private void CheckCreative(int rowIndex, ref Dictionary<string, string[]> creativeDictionary, ref Dictionary<string, string[]> placementDictionary, 
        //    ref string[] creativeAttributes, string[] creativeNameValue, ref string[] placementAttributes, string[] placementNameValue, bool no_rule_check)
        //{
        //    string errorDescription = string.Empty;
        //    if (creativeDictionary.ContainsKey(_creativeName))
        //    {
        //        if (creativeNameValue[1] != _headline)
        //        {
        //            errorDescription = "Headline '" + _headline + "' contradicts line " + creativeNameValue[0] +
        //                                " where Creative '" + _creativeName + "' was listed with Headline '" + creativeNameValue[1] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }

        //        if (creativeNameValue[2] != _description1)
        //        {
        //            errorDescription = "Headline '" + _description1 + "' contradicts line " + creativeNameValue[0] +
        //                                " where Creative '" + _creativeName + "' was listed with Description Line 1 '" + creativeNameValue[2] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }

        //        if (creativeNameValue[3] != _description2)
        //        {
        //            errorDescription = "Headline '" + _description2 + "' contradicts line " + creativeNameValue[0] +
        //                                " where Creative '" + _creativeName + "' was listed with Description Line 2 '" + creativeNameValue[3] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }

        //        if (creativeNameValue[4] != _displayURL)
        //        {
        //            errorDescription = "Headline '" + _displayURL + "' contradicts line " + creativeNameValue[0] +
        //                                " where Creative '" + _creativeName + "' was listed with Display URL'" + creativeNameValue[4] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }
        //    }
        //    else
        //    {
        //        creativeAttributes[0] = rowIndex.ToString();
        //        creativeAttributes[1] = _headline;
        //        creativeAttributes[2] = _description1;
        //        creativeAttributes[3] = _description2;
        //        creativeAttributes[4] = _displayURL;
        //        creativeAttributes[5] = "0"; //' number of keywords
        //        creativeDictionary.Add(_creativeName, creativeAttributes);

        //        placementAttributes[0] = placementNameValue[0];
        //        placementAttributes[1] = placementNameValue[1];
        //        placementAttributes[2] = placementNameValue[2];
        //        placementAttributes[3] = (Convert.ToInt32(placementNameValue[3]) + 1).ToString();
        //        placementDictionary[_placementName] = placementAttributes;

        //        if (!no_rule_check)
        //        {
        //            if (Convert.ToInt32(placementNameValue[3]) > _RULE_Max_Ads_Per_Placement)
        //            {
        //                errorDescription = "There can only be a maximum of " + _RULE_Max_Ads_Per_Placement + " Creatives per Placement.";
        //                WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //            }
        //        }
        //    }
        //}

        ///// <summary>
        ///// Check the keyword value errors
        ///// </summary>
        //private void CheckKeyword(int rowIndex, string aggregateKey, ref int totalKeywordsInSheet, ref Dictionary<string, string[]> keywordDictionary, ref Dictionary<string, string[]> creativeDictionary,
        //    ref string[] keywordAttributes, string[] keywordValue, ref string[] creativeAttributes, string[] creativeNameValue, bool no_rule_check)
        //{
        //    string errorDescription = string.Empty;

        //    if (keywordDictionary.ContainsKey(aggregateKey))
        //    {
        //        if (keywordValue[1] != _clickURL)
        //        {
        //            errorDescription = "Click URL '" + _clickURL + "' contradicts line " + keywordValue[0] +
        //                                " where the same Placement, Creative, Keyword combination was listed with Click URL '" + keywordValue[1] + "'";
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }

        //        if (Convert.ToDouble(keywordValue[2]) != _maxCPC)
        //        {
        //            errorDescription = "Max CPC value of " + _maxCPC.ToString() + " contradicts line " + keywordValue[1] +
        //                                " where the same Placement, Creative, Keyword combination was listed with a Max CPC value of " + keywordValue[2];
        //            WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //        }
        //    }
        //    else
        //    {
        //        keywordAttributes[0] = rowIndex.ToString();
        //        keywordAttributes[1] = _clickURL;
        //        keywordAttributes[2] = _maxCPC.ToString();
        //        keywordDictionary.Add(aggregateKey, keywordAttributes);

        //        creativeAttributes[0] = creativeNameValue[0];
        //        creativeAttributes[1] = creativeNameValue[1];
        //        creativeAttributes[2] = creativeNameValue[2];
        //        creativeAttributes[3] = creativeNameValue[3];
        //        creativeAttributes[4] = creativeNameValue[4];
        //        creativeAttributes[5] = (Convert.ToInt32(creativeNameValue[5]) + 1).ToString();
        //        creativeDictionary[_creativeName] = creativeAttributes;

        //        totalKeywordsInSheet = totalKeywordsInSheet + 1;

        //        if (!no_rule_check)
        //        {
        //            if (Convert.ToInt32(creativeNameValue[5]) > _RULE_Max_Keywords_Per_Ad)
        //            {
        //                errorDescription = "There can only be a maximum of " + _RULE_Max_Keywords_Per_Ad.ToString() + " Keywords per Creative.";
        //                WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //            }

        //            if (totalKeywordsInSheet > _RULE_Max_Keywords_Per_Sheet)
        //            {
        //                errorDescription = "There can only be a maximum of " + _RULE_Max_Keywords_Per_Sheet.ToString() + " Keywords per Keyword Sheet.";
        //                WriteErrors(rowIndex, errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //            }
        //        }
        //    }
        //}

        ///// <summary>
        ///// Check the Creative value errors
        ///// </summary>
        //private void CheckCreativeValue(Dictionary<string, string[]> creativeDictionary)
        //{
        //    int count = 0;
        //    string errorDescription;

        //    foreach (KeyValuePair<string, string[]> myEntry in creativeDictionary)
        //    {
        //        if (Convert.ToInt32(myEntry.Value[5]) < _RULE_Min_Keywords_Per_Ad)
        //        {
        //            count = count + 1;
        //            if (count > _RULE_Num_Ads_With_Less_Than_Required_Amt_of_Keywords)
        //            {
        //                errorDescription = "The limit of " + _RULE_Num_Ads_With_Less_Than_Required_Amt_of_Keywords +
        //                    " creatives with " + (_RULE_Min_Keywords_Per_Ad - 1) + "  or less keywords per creative has been exceeded";
        //                WriteErrors(Convert.ToInt32(myEntry.Value[0]), errorDescription, _campaignId, _placementSheetId, _placementSheetName);
        //            }
        //        }
        //    }
        //}

        ///// <summary>
        ///// Get the column values from the csv file
        ///// </summary>
        //private void GetColumnValues(OleDbDataReader rdOrigFile)
        //{
        //    _publisherName = rdOrigFile["publisherName"] is System.DBNull ? "" : rdOrigFile["publisherName"].ToString();
        //    _placementName = rdOrigFile["placementName"] is System.DBNull ? "" : rdOrigFile["placementName"].ToString();
        //    _creativeName = rdOrigFile["creativeName"] is System.DBNull ? "" : rdOrigFile["creativeName"].ToString();
        //    _headline = rdOrigFile["headline"] is System.DBNull ? "" : rdOrigFile["headline"].ToString();
        //    _description1 = rdOrigFile["description1"] is System.DBNull ? "" : rdOrigFile["description1"].ToString();
        //    _description2 = rdOrigFile["description2"] is System.DBNull ? "" : rdOrigFile["description2"].ToString();
        //    _displayURL = rdOrigFile["displayURL"] is System.DBNull ? "" : rdOrigFile["displayURL"].ToString();
        //    _locale = rdOrigFile["locale"] is System.DBNull ? "" : rdOrigFile["locale"].ToString();
        //    _keyword = rdOrigFile["keyword"] is System.DBNull ? "" : rdOrigFile["keyword"].ToString();
        //    _clickURL = rdOrigFile["clickURL"] is System.DBNull ? "" : rdOrigFile["clickURL"].ToString();
        //    _maxCPC = rdOrigFile["maxCPC"] is System.DBNull ? 0.0 : Convert.ToDouble(rdOrigFile["maxCPC"].ToString());
        //}



        ///// <summary>
        /////This function returns a select statement based on choices the user made in keywordTrackingColumns.
        /////For each field, the user either chose a value or a column. If they chose a value for a particular field,
        ///// </summary>
        ///// <param name="tableName"></param>
        ///// <returns></returns>
        //private string GetSelectStatement(string tableName)
        //{
        //    string strSQL;

        //    strSQL = "SELECT ";
        //    strSQL = strSQL + "Publisher as publisherName, ";
        //    strSQL = strSQL + "[Placement Name] as placementName, ";
        //    strSQL = strSQL + "[Creative Name] as creativeName, ";
        //    strSQL = strSQL + "Headline, ";
        //    strSQL = strSQL + "[Description Line 1] as description1, ";
        //    strSQL = strSQL + "[Description Line 2] as description2, ";
        //    strSQL = strSQL + "[Display URL] as displayURL, ";
        //    strSQL = strSQL + "[Geographic Location] as locale, ";
        //    strSQL = strSQL + "Keyword, ";
        //    strSQL = strSQL + "[Destination URL] as clickURL, ";
        //    strSQL = strSQL + "[Max CPC] as maxCPC FROM [" + tableName + "]";
        //    //strSQL = "SELECT * FROM [" + tableName + "]";
        //    return strSQL;
        //}



        ///// <summary>
        ///// This function is to write down the error information to a file
        ///// </summary>
        ///// <param name="lineNumber"></param>
        ///// <param name="errorDescription"></param>
        //private void WriteErrors(int lineNumber, string errorDescription, int campaignid, int placementSheetId, string placementSheetName)
        //{
        //    _errorCount++;
        //    if (lineNumber < 0)
        //    {
        //        lineNumber = 0;
        //    }

        //    TransactionLog.Error(lineNumber.ToString(), errorDescription, campaignid.ToString(), placementSheetId.ToString(), placementSheetName);
        //}
        //#endregion private methods
    }
}
