﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Xml;
using Bluestreak.TrafficSheetValidation;
using TransactionLog;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concrete a class to check file error information
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>06/28/2008</date>
    public partial class BSFileErrorCheckJob : BSJob
    {
        #region database definition

        private string _filePath = string.Empty;
        private string _tsvFilePath = string.Empty;
        private int _placementSheetId;
        private string _placementSheetName = string.Empty;
        private string _publisherName = string.Empty;
        private int _campaignId;
        private string _compaignName;
        private int _advid;
        private string _advname;
        private CSVFormat _fileFormat;
        private int _version;
        #endregion

        #region public method
        /// <summary>
        /// Override the run() method, run File file error check 
        /// </summary>
        public override void Run()
        {
            int jobId = 0;
            string errorDescription = string.Empty;
            string fileFormat = string.Empty;
            string ErrorFilePath =string.Empty;
            try
            {
                bool isOversize;
                bool isPlacementSheetExist;
                jobId = this.GetJobId(_queueId, JobType.BSFileErrorCheckJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet name: {2} file error check starting", _queueId, jobId, _placementSheetName), jobId);
                SetParameterValues();
                               
                string dataError = CheckBlankLine();

                if (dataError == "No data in the file.")
                {
                    throw new Exception("There is no data in the file. ;Keyword Sheet: " + _placementSheetName + " - No data in the file");
                }
                else if (dataError.IndexOf("Blank line found") > 0)
                {
                    throw new Exception(dataError + " ;Keyword Sheet: " + _placementSheetName + " - Blank line found");
                }
                else if (dataError.IndexOf("Illegal double quote character found") > 0)
                {
                    throw new Exception(dataError + " ;Keyword Sheet: " + _placementSheetName + " - Illegal double quote character found");
                }

                bool placementNameValid = CheckPlaceSheetName();
                if (!placementNameValid)
                {
                    throw new Exception("The keyword sheet name must be 2 - 60 characters long, the file name must be not over 64 and may contain only letters, digits, and hyphens. ;Keyword Sheet: " + _placementSheetName + " - Name is invalid");
                }

                isOversize = PublicFunctionUtil.CheckFileSize(_filePath, Convert.ToInt64(ConfigurationSettings.AppSettings["MaxFileSize"].ToString()));

                if (isOversize)
                {
                    throw new Exception("There is a 10 megabytes size limit per each file uploaded. ;Keyword Sheet: " + _placementSheetName + " - File is oversize");
                }

                fileFormat = PublicFunctionUtil.GetFileEncoding(_filePath);
                if ( fileFormat == "ASCII")
                {
                    _fileFormat = CSVFormat.Ascii; 
                }
                else if (fileFormat == "It is an empty file.")
                {
                    throw new Exception("An error occurred while processing your keyword sheet <" + _placementSheetName + ">. Error received: The file uploaded is empty. Please upload your file again. ;Issue Processing Keyword Sheet: <" + _placementSheetName + ">");
                }
                else if (fileFormat == "UNICODE")
                {
                    bool isTabDelimitedForUTF16 = CheckTabDelimitedForUTF16();
                    if (!isTabDelimitedForUTF16) //Check delimited not ","
                    {
                        throw new Exception("The file you uploaded is not a valid UTF16 file. Please reformat and upload again. ;Keyword Sheet: " + _placementSheetName + " - File Format Error");
                    }
                    _fileFormat = CSVFormat.UTF16;
                }
                else
                {
                    throw new Exception("The file you uploaded is neither an Asccii or valid UTF16 file. ;Keyword Sheet: " + _placementSheetName + " - File Format Error");
                }

                //string campaignName = Path.GetFileName(_filePath).Substring(0, Path.GetFileName(_filePath).IndexOf("_"));
                GetFileVersion();

                if (_version == 1)
                {
                    //errorDescription = fileValidation.validateSheet(_filePath, _placementSheetId, _placementSheetName, _campaignId, "", "", ErrorFilePath, _version);
                    throw new Exception("The file you uploaded is not a new format version. ;Keyword Sheet: " + _placementSheetName + " - Old format version");

                }

                bool isHeadLineCorrective = CheckHeadLine();
                if (!isHeadLineCorrective)
                {
                    throw new Exception("The headline of the keyword sheet is not corrective. ;Keyword Sheet: " + _placementSheetName + " - HeadLine Error");
                }

                WriteSchemaFile(Path.GetDirectoryName(_filePath) + "\\schema.ini", _version, _fileFormat);
                isPlacementSheetExist = CheckPlacementSheetExists();
                if (isPlacementSheetExist)
                {
                    AddEditPlacementSheet(false);
                }
                else
                {
                    AddEditPlacementSheet(true);
                }

                //ErrorFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString()+ "\\Error\\";
                ErrorFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();

                string ErrorFileName = ErrorFilePath + "\\Error\\JobServiceError_" + _campaignId + "_" + _placementSheetId + " _" + _placementSheetName + "_" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";

                if (File.Exists(ErrorFileName))
                {
                    PublicFunctionUtil.CheckWriteLock(ErrorFileName);
                    File.Delete(ErrorFileName);
                }

                Validation fileValidation = new Validation();
                if (_version == 2)
                {
                    errorDescription = fileValidation.validateSheet(_filePath, _tsvFilePath, _placementSheetId, _placementSheetName, _campaignId, _placementSheetName, _publisherName, ErrorFilePath, _version);
                }

                if (errorDescription.Length == 0)
                {
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet name: {2} file error check compeleted successfully", _queueId, jobId, _placementSheetName), jobId, JobStatus.Successful);
                }
                else
                {
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet name: {2}file error check import failed with Error: {3}", _queueId, jobId, _placementSheetName, errorDescription), jobId, JobStatus.Failed);
                    throw new Exception(this._placementSheetId + ", there are some errors in the file");
                }
                fileValidation.Dispose();
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet name: file error check import failed with Error: {3}", _queueId, jobId, _placementSheetName, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            string publisherName;
            _oQuery.SQL = "JobService_GetJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._advid = _oQuery.FieldByName("Adv_id").AsInteger;
                this._advname = _oQuery.FieldByName("AdvertiserName").AsString;
                this._campaignId = _oQuery.FieldByName("campaign_id").AsInteger;
                this._compaignName = _oQuery.FieldByName("campaignName").AsString;
                this._placementSheetId = _oQuery.FieldByName("placementSheet_id").AsInteger;
                this._placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                this._filePath = _oQuery.FieldByName("filePath").AsString;
                publisherName= Path.GetFileNameWithoutExtension(_filePath);
                if (publisherName.IndexOf("_") > 0)
                {
                    publisherName = publisherName.Substring(publisherName.IndexOf("_") + 1);
                }

                if (publisherName.IndexOf("_") > 0)
                {
                    this._publisherName = publisherName.Substring(publisherName.IndexOf("_") + 1);
                }
            }

            string newFileName = Path.GetDirectoryName(_filePath) + "\\" + this._placementSheetName + ".csv";
            this._tsvFilePath = Path.GetDirectoryName(_filePath) + @"\cleanFiles\" + this._placementSheetName + ".tsv";
            if (File.Exists(newFileName))
            {
                File.Delete(newFileName);
            }
            File.Copy(this._filePath, newFileName);
            File.Delete(this._filePath);
            this._filePath = newFileName;

            _oQuery.SQL = "JobService_UpdateFileName";
            _oQuery.ParamByName("queueId").AsInteger = _queueId;
            _oQuery.ParamByName("filePath").AsString = newFileName;
            _oQuery.ParamByName("tsvFilePath").AsString = this._tsvFilePath;
            _oQuery.Open();
        }
        #endregion public method

        #region private method
        private bool CheckPlacementSheetExists()
        {
            int placementSheetExists=0;
            _oQuery.SQL = "ion_checkPlacementSheetExists";
            _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
            _oQuery.ParamByName("placementSheetName").AsString = _placementSheetName;
            _oQuery.ParamByName("placementSheetExists").AsTinyInt = 0;
            _oQuery.Params.SetParameterDirection("placementSheetExists", ParameterDirection.Output);
            _oQuery.Open();

            placementSheetExists = int.Parse(_oQuery.Params.GetStringParamValue("placementSheetExists"));
            return placementSheetExists == 1;
        }

        /// <summary>
        /// Add the a new placement sheet, or Edit a placement sheet
        /// </summary>
        private void AddEditPlacementSheet(bool isAddNewPlacementSheet)
        {
            if (isAddNewPlacementSheet)
            {
                _oQuery.SQL = "ion_addPlacementSheet";
                _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
                _oQuery.ParamByName("description").AsString = _placementSheetName;
                _oQuery.ParamByName("EncodingID").AsInteger = _fileFormat == CSVFormat.Ascii ? 0 : 2;
                _oQuery.ParamByName("formatVersion").AsTinyInt = 2;
                _oQuery.ParamByName("defaultPublisher").AsString = _publisherName;
                _oQuery.ParamByName("defaultSiteName").AsString = _placementSheetName;
                _oQuery.ParamByName("placementSheetID").AsTinyInt = 0;
                _oQuery.Params.SetParameterDirection("placementSheetID", ParameterDirection.Output);
                _oQuery.Open();
                _placementSheetId = int.Parse(_oQuery.Params.GetStringParamValue("placementSheetID"));

                if (_placementSheetId == -99)
                {
                    throw new Exception("There are problem to add new placementSheet ;Format Error Keyword Sheet: " + _placementSheetName);
                }
            }
            else
            {
                int formatVersion = 1;
                _oQuery.SQL = "ion_getPlacementSheetProperties";
                _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
                _oQuery.ParamByName("placementSheetID").AsInteger = _placementSheetId;
                _oQuery.Open();

                if (!_oQuery.EOF())
                {
                    formatVersion = _oQuery.FieldByName("formatVersion").AsInteger;
                }

                if (formatVersion >= 2)
                {
                    int success = 0;
                    _oQuery.SQL = "JobService_GetExistPlacementId";
                    _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
                    _oQuery.ParamByName("placementSheetName").AsString = _placementSheetName;
                    _oQuery.Open();
                    if (!_oQuery.EOF())
                    {
                        _placementSheetId = _oQuery.FieldByName("placementSheetId").AsInteger;
                    }

                    _oQuery.SQL = "ion_renamePlacementSheet";
                    _oQuery.ParamByName("placementSheetId").AsInteger = _placementSheetId;
                    _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
                    _oQuery.ParamByName("newDescription").AsString = _placementSheetName;
                    _oQuery.ParamByName("EncodingID").AsInteger = _fileFormat == CSVFormat.Ascii ? 0 : 2;
                    _oQuery.ParamByName("defaultSiteName").AsString = _placementSheetName;
                    _oQuery.ParamByName("success").AsTinyInt = 0;
                    _oQuery.Params.SetParameterDirection("success", ParameterDirection.Output);
                    _oQuery.Open();

                    success = _oQuery.Params.GetStringParamValue("success").ToString().ToUpper() == "TRUE" ? 1 : 0;
                }
                else
                {
                    throw new Exception("Edits to keyword sheets created with this format need to be processed through the Bluestreak user interface."
                            + " Only new format sheets can be edited through FTP. Please contact support@bluestreak.com if you need assistance. ;Format Error Keyword Sheet: "
                            + _placementSheetName);
                }
            }
            _oQuery.SQL = "JobService_updatePlacementSheetID";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("placementSheetId").AsInteger = _placementSheetId;
            _oQuery.Open();
        }

        /// <summary>
        /// Write the schema.ini file
        /// </summary>
        /// <param name="schemaPath"></param>
        /// <param name="version"></param>
        /// <param name="csvformat"></param>
        private void WriteSchemaFile(string schemaPath, int version, CSVFormat csvformat)
        {
            if (csvformat == CSVFormat.Ascii || csvformat == CSVFormat.UTF16)
            {
                string fileName = Path.GetFileName(_filePath);
                using (StreamWriter sw = new StreamWriter(schemaPath, false))
                {
                    sw.WriteLine("[" + fileName + "]");
                    sw.WriteLine("ColNameHeader=false");

                    XmlDocument doc = new XmlDocument();
                    doc.Load("KeywordConfig.xml");
                    string id = "s" + version;
                    XmlElement sqlList = doc.GetElementById(id);
                    XmlNodeList colList = sqlList.ChildNodes;

                    if (csvformat == CSVFormat.Ascii)
                    {
                        sw.WriteLine("Format=CSVDelimited");
                    }
                    else
                    {
                        sw.WriteLine("Format=TABDelimited");
                        sw.WriteLine("CharacterSet=1200");
                    }

                    if (version == 1)
                    {
                        int i = 1;
                        foreach (XmlElement element in colList)
                        {
                            sw.WriteLine("col" + i + "=" + element.InnerText.Trim() + " memo");
                            i++;
                        }
                    }
                    else
                    {
                        int i = 1;
                        foreach (XmlElement element in colList)
                        {
                            if (element.InnerText.IndexOf("as ") < 0)
                            {
                                sw.WriteLine("col" + i + "=" + element.InnerText.Trim() + " memo");
                                i++;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Check whether the UTF16 file is delimit by Tab
        /// </summary>
        /// <returns></returns>
        private bool CheckTabDelimitedForUTF16()
        {
            char[] dilimiter = { '\t' };
            string[] cols = null;

            string line = PublicFunctionUtil.GetOneLineDataFromCSVFile(_filePath);
            if (line != null)
            {
                cols = line.Split(dilimiter, StringSplitOptions.RemoveEmptyEntries);
            }
            else
            {
                return false;
            }

            return cols.Count() > 3 ? true : false;
        }

        private void GetFileVersion()
        {
            string[] cols;
            string line =PublicFunctionUtil.GetOneLineDataFromCSVFile(_filePath);
            if (_fileFormat == CSVFormat.UTF16)
            {
                char[] dilimiter = { '\t' };
                cols = line.Split(dilimiter);
            }
            else
            {
                char[] dilimiter = { ',' };
                cols = line.Split(dilimiter);
            }
            _version = cols.Count() > 5 ? 1 : 2;
        }

        private bool CheckPlaceSheetName()
        {
            int maxFilenameLength = Path.GetFileName(_filePath).Length;
            if (this._placementSheetName.Trim().Length >= 2 && this._placementSheetName.Trim().Length <= 60 && PublicFunctionUtil.IsAlphaNumeric(this._placementSheetName) && maxFilenameLength <= 64)
            //if (this._placementSheetName.Trim().Length >= 2 && this._placementSheetName.Trim().Length <= 60 && PublicFunctionUtil.IsAlphaNumeric(this._placementSheetName) && maxFilenameLength <=192)
            {
                return true;
            }

            return false;
        }

        private bool CheckHeadLine()
        {
            string line = string.Empty;
            string[] cols;
            string[] headline = new string[4] { "Ad Group", "Geographic Location", "Keyword", "Destination URL" };
            using (StreamReader sw = new StreamReader(_filePath))
            {
                if (!sw.EndOfStream)
                {
                    line = sw.ReadLine();
                }
            }

            if (_fileFormat == CSVFormat.UTF16)
            {
                char[] dilimiter = { '\t' };
                cols = line.Split(dilimiter);
            }
            else
            {
                char[] dilimiter = { ',' };
                cols = line.Split(dilimiter);
            }

            if (cols[0].ToUpper() != headline[0].ToUpper() || cols[1].ToUpper() != headline[1].ToUpper() || cols[2].ToUpper() != headline[2].ToUpper() || cols[3].ToUpper() != headline[3].ToUpper())
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private string CheckBlankLine()
        {
            string dataError = string.Empty;
            string line;
            int numberOfQuote;

            using (StreamReader sw = new StreamReader(_filePath))
            {
                int lineNo = 1;
                if (!sw.EndOfStream)
                {
                    line = sw.ReadLine();
                }

                if (!sw.EndOfStream)
                {
                    //line = sw.ReadLine();
                    while (!sw.EndOfStream && lineNo <100)
                    {
                        lineNo++;
                        line = sw.ReadLine();

                        numberOfQuote =PublicFunctionUtil.CountOccurrances(line,"\"");
                        if (numberOfQuote % 2 > 0)
                        {
                            dataError += "Line " + lineNo + ": Illegal double quote character found!";
                            break;
                        }

                        if (line.Trim()=="")
                        {
                            dataError += "Line " + lineNo + ": Blank line found!";
                            break;
                        }
                    }
                }
                else
                {
                    dataError = "No data in the file.";
                }
            }
            return dataError;
        }
        #endregion private method
    }
}
