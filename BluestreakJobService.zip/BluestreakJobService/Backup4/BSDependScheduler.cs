﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bluestreak.BSJobService
{
    public class BSDependScheduler : BSJobScheduler
    {
        public override void AddToSchedule()
        {
            throw new NotImplementedException();
        }

        public override void SetScheduleParameter()
        {
            throw new NotImplementedException();
        }

        public override void Run()
        {
            throw new NotImplementedException();
        }
    }
}
