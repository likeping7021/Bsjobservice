﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Configuration;
using System.IO;
using System.Collections;

namespace Bluestreak.BSJobService
{
    public class JobProcess
    {
        #region parameters
        public delegate void JobFinished(object sender, EventArgs e);
        public event JobFinished Finished;
        private BSMasterJob _masterJob;
        private bool _hasError;
        private string _dbtag;
        private BSDynamicDBJobLoader _newJobschedule;
        #endregion parameters

        #region public method
        public JobProcess()
        {
            _masterJob = new BSMasterJob();
        }

        /// <summary>
        /// Initialize the job information
        /// </summary>
        /// <param name="DB_TAG_INFO"></param>
        /// <param name="Jobschedule"></param>
        public void Initialize(string dbTagInfo, BSDynamicDBJobLoader Jobschedule)
        {
            this._dbtag = dbTagInfo;
            this._newJobschedule = new BSDynamicDBJobLoader(dbTagInfo);
            this._newJobschedule.CAMPAIGNID = Jobschedule.CAMPAIGNID;
            this._newJobschedule.PLACEMENTSHEETID = Jobschedule.PLACEMENTSHEETID;
            this._newJobschedule.PLACEMENTSHEETNAME = Jobschedule.PLACEMENTSHEETNAME;
            this._newJobschedule.ID = Jobschedule.ID;
            this._newJobschedule.EMAILNOTIFICATIONTO = Jobschedule.EMAILNOTIFICATIONTO;
            this._newJobschedule.EMAILNOTIFICATIONCC = Jobschedule.EMAILNOTIFICATIONCC;

            foreach (KeyValuePair<int, string> jobSquence in Jobschedule._jobSequence)
            {
                this._newJobschedule._jobSequence.Add(jobSquence.Key, jobSquence.Value);
            }
        }

        public void Process()
        {
            string SMTP = ConfigurationSettings.AppSettings["SMTP"].ToString();
            string emailSender = ConfigurationSettings.AppSettings["EmailSender"].ToString();
            int campaignId = _newJobschedule.CAMPAIGNID;
            int placementSheetId = _newJobschedule.PLACEMENTSHEETID;
            int queueId = _newJobschedule.ID;
            string placementSheetName = _newJobschedule.PLACEMENTSHEETNAME;
            string emailTo = _newJobschedule.EMAILNOTIFICATIONTO;
            string emailCC = _newJobschedule.EMAILNOTIFICATIONCC;

            TransactionLog.log("Keyword upload and traffic process begin," + " Queue ID: " + queueId + " KeywordSheet ID: " + placementSheetId +
                        " KeywordSheet Name: " + placementSheetName);

            try
            {
                _masterJob.Initialize(queueId, _dbtag);

                foreach (KeyValuePair<int, string> jobSquence in this._newJobschedule._jobSequence)
                {
                    //Importantly, dynamically define the jobType when loading jobType from DB
                    Type BSJobType = Type.GetType(jobSquence.Value, true);
                    var sheduledJob = (BSJob)Activator.CreateInstance(BSJobType);
                    sheduledJob.Initialize(queueId, _dbtag);
                    _masterJob.AddJob(jobSquence.Key, sheduledJob);
                }

                _masterJob.Run();
            }
            catch (FileLoadException ex5)
            { }
            catch (Exception ex)
            {
                int indexPlacementId = ex.Message.IndexOf(", there are some errors in the file");
                if (indexPlacementId > 0)
                {
                    placementSheetId = Convert.ToInt32(ex.Message.Substring(0, indexPlacementId));
                }

                string ErrorFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();
                string ErrorFileName = ErrorFilePath + "\\Error\\JobServiceError_" + campaignId + "_" + placementSheetId + " _" + placementSheetName + "_" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";

                this.HAS_ERRROR = true;
                TransactionLog.log("Error to finish the keyword upload and traffic process. " + ex.ToString());

                if (File.Exists(ErrorFileName))
                {
                    try
                    {
                        //Send the errorCode file which generated during importing keyword sheet
                        PublicFunctionUtil.EmailError(ErrorFileName, SMTP, emailSender, emailTo, emailCC, "Keyword sheet: " + placementSheetName + " Upload Failure", placementSheetName, true);
                    }
                    catch (Exception ex2) { }
                }
                else if (ex.Message.IndexOf("file you uploaded is not a valid") > 0 || ex.Message.IndexOf("file you uploaded is neither an Asccii") > 0)
                {
                    try
                    {
                        char[] seperator = { ';' };
                        string[] emailMessage = ex.Message.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                        PublicFunctionUtil.EmailError(emailMessage[0], SMTP, emailSender, emailTo, emailCC, emailMessage[1], "", false);
                    }
                    catch (Exception ex3) { }
                }
                else if (ex.Message.IndexOf("is a 10 megabytes size limit per") > 0 || ex.Message.IndexOf("publisher does not exist") > 0 || ex.Message.IndexOf("The file uploaded is empty") > 0
                    || ex.Message.IndexOf("keyword sheet name must be 2 - 60 characters long") > 0 || ex.Message.IndexOf("no data in the file") > 0 || ex.Message.IndexOf("headline of the keyword sheet is not corrective") > 0
                    || ex.Message.IndexOf("Blank line found") > 0 || ex.Message.IndexOf("Illegal double quote character found") > 0 || ex.Message.IndexOf("be processed through the Bluestreak user interface") > 0)
                {
                    try
                    {
                        char[] seperator = { ';' };
                        string[] emailMessage = ex.Message.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                        PublicFunctionUtil.EmailError(emailMessage[0], SMTP, emailSender, emailTo, emailCC, emailMessage[1], "", false);
                    }
                    catch (Exception ex3) { }
                }
                else if (ex.Message.IndexOf("Permission Denied") > 0 || ex.Message.IndexOf("Please validate your FTP site and configuration") > 0 || ex.Message.IndexOf("you uploaded is not a new format version") > 0)
                {
                    emailCC = emailCC.Length == 0 ? "support@bluestreak.com" : emailCC + ";" + "support@bluestreak.com";
                    try
                    {
                        char[] seperator = { ';' };
                        string[] emailMessage = ex.Message.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                        PublicFunctionUtil.EmailError(emailMessage[0], SMTP, emailSender, emailTo, emailCC, emailMessage[1], "", false);
                    }
                    catch (Exception ex3) { }
                }
                else
                {
                    bool retryAgain = true;
                    try
                    {
                        retryAgain = _masterJob.RetryRun();
                    }
                    catch { }

                    if (!retryAgain)
                    {
                        try
                        {
                            if (placementSheetName.Trim().Length > 0)
                            {
                                PublicFunctionUtil.EmailError("", SMTP, emailSender, emailTo, emailCC, "Processing issue encountered keyword sheet: " + placementSheetName, placementSheetName
                                    + ". Please try uploading your file again. Contact support@bluestreak.com if you need assistance.", false);
                            }
                        }
                        catch (Exception ex1) { }
                    }
                }
            }
            finally
            {
                _masterJob.Dispose();
            }

            Finished(this, new EventArgs());
            TransactionLog.log("Keyword upload and traffic process finshed." + " Queue ID: " + _newJobschedule.ID + " Error :" + this.HAS_ERRROR.ToString());
        }

        #endregion public method

        #region properties
        public bool HAS_ERRROR
        {
            get
            {
                return _hasError;
            }
            set
            {
                _hasError = value;
            }
        }
        public BSMasterJob Process_masterjob
        {
            get
            {
                throw new System.NotImplementedException();
            }
        }
        #endregion
    }
}
