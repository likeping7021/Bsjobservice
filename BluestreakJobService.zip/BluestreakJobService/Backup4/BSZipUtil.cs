﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using java.util;
using java.util.zip;

namespace Bluestreak.BSJobService
{
    public delegate Enumeration EnumerationMethod();
    public delegate bool FilterEntryMethod(ZipEntry e);

    /// <summary>
    /// Concreate a class to zip the report for Email
    /// </summary>
    /// <author>Keping Li</author>
    /// <date>12/20/2007</date>
    public static class ZipUtils
    {
        /// <summary>
        /// Copy stream of file to another file
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public static void CopyStream(java.io.InputStream from, java.io.OutputStream to)
        {
            sbyte[] buffer = new sbyte[8192];
            int got;
            while ((got = from.read(buffer, 0, buffer.Length)) > 0)
                to.write(buffer, 0, got);
        }

                /// <summary>
        /// Extract the zip file, unzip files, this apply for the case that there is only one file in the zip files
        /// </summary>
        /// <param name="file"></param>
        /// <param name="path"></param>
        /// <param name="filter"></param>
        public static void ExtractZipFile(ZipFile file, string fileName)
        {
            FilterEntryMethod filter = null;
            foreach (ZipEntry entry in new EnumerationAdapter(new EnumerationMethod(file.entries)))
            {

                if (!entry.isDirectory())
                {
                    if ((filter == null || filter(entry)))
                    {
                        java.io.InputStream s = file.getInputStream(entry);
                        try
                        {
                            //string fname = Path.GetFileName(entry.getName());
                            java.io.FileOutputStream dest = new java.io.FileOutputStream(fileName);
                            try
                            {
                                CopyStream(s, dest);
                            }
                            finally
                            {
                                dest.close();
                            }
                        }
                        finally
                        {
                            s.close();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Extract the zip file, unzip files
        /// </summary>
        /// <param name="file"></param>
        /// <param name="path"></param>
        /// <param name="filter"></param>
        public static void ExtractZipFile(ZipFile file, string path, FilterEntryMethod filter)
        {
            foreach (ZipEntry entry in new EnumerationAdapter(new EnumerationMethod(file.entries)))
            {
                if (!entry.isDirectory())
                {
                    if ((filter == null || filter(entry)))
                    {
                        java.io.InputStream s = file.getInputStream(entry);
                        try
                        {
                            string fname = Path.GetFileName(entry.getName());
                            string newpath = Path.Combine(path, Path.GetDirectoryName(entry.getName()));

                            Directory.CreateDirectory(newpath);

                            java.io.FileOutputStream dest = new java.io.FileOutputStream(Path.Combine(newpath, fname));
                            try
                            {
                                CopyStream(s, dest);
                            }
                            finally
                            {
                                dest.close();
                            }
                        }
                        finally
                        {
                            s.close();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create an empty zip file
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static ZipFile CreateEmptyZipFile(string fileName)
        {
            new ZipOutputStream(new java.io.FileOutputStream(fileName)).close();
            return new ZipFile(fileName);
        }

        /// <summary>
        /// Build the zip file
        /// </summary>
        /// <param name="file"></param>
        /// <param name="filter"></param>
        /// <param name="newFiles"></param>
        /// <returns></returns>
        public static ZipFile UpdateZipFile(ZipFile file, FilterEntryMethod filter, string[] newFiles)
        {
            string prev = file.getName();
            string tmp = Path.GetTempFileName();
            ZipOutputStream to = new ZipOutputStream(new java.io.FileOutputStream(tmp));
            try
            {
                CopyEntries(file, to, filter);
                // add entries here
                if (newFiles != null)
                {
                    foreach (string f in newFiles)
                    {
                        //During zipping, remove the Directory path, just keep the fime name.
                        ZipEntry z = new ZipEntry(f.Remove(0, Path.GetDirectoryName(f).Length + 1));
                        z.setMethod(ZipEntry.DEFLATED);
                        to.putNextEntry(z);
                        try
                        {
                            java.io.FileInputStream s = new java.io.FileInputStream(f);
                            try
                            {
                                CopyStream(s, to);
                            }
                            finally
                            {
                                s.close();
                            }
                        }
                        finally
                        {
                            to.closeEntry();
                        }
                    }
                }
            }
            finally
            {
                to.close();
            }
            file.close();

            // now replace the old file with the new one
            File.Copy(tmp, prev, true);
            File.Delete(tmp);

            return new ZipFile(prev);
        }

        /// <summary>
        /// Copy the one ZipFile to ZipOutputStream
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public static void CopyEntries(ZipFile from, ZipOutputStream to)
        {
            CopyEntries(from, to, null);
        }

        /// <summary>
        /// Filte and Copy the one ZipFile to ZipOutputStream
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public static void CopyEntries(ZipFile from, ZipOutputStream to, FilterEntryMethod filter)
        {
            foreach (ZipEntry entry in new EnumerationAdapter(new EnumerationMethod(from.entries)))
            {
                if (filter == null || filter(entry))
                {
                    java.io.InputStream s = from.getInputStream(entry);
                    try
                    {
                        to.putNextEntry(entry);
                        try
                        {
                            CopyStream(s, to);
                        }
                        finally
                        {
                            to.closeEntry();
                        }
                    }
                    finally
                    {
                        s.close();
                    }
                }
            }
        }
    }

    /// <summary>
    /// Concreate a class to wraps java enumerators 
    /// </summary>
    /// <author>Keping Li</author>
    /// <date>12/26/2007</date>
    public class EnumerationAdapter : IEnumerable
    {
        private class EnumerationWrapper : IEnumerator
        {
            private EnumerationMethod m_Method;
            private Enumeration m_Wrapped;
            private object m_Current;

            public EnumerationWrapper(EnumerationMethod method)
            {
                m_Method = method;
            }

            // IEnumerator
            public object Current
            {
                get { return m_Current; }
            }

            public void Reset()
            {
                m_Wrapped = m_Method();
                if (m_Wrapped == null)
                    throw new InvalidOperationException();
            }

            public bool MoveNext()
            {
                if (m_Wrapped == null)
                    Reset();
                bool Result = m_Wrapped.hasMoreElements();
                if (Result)
                    m_Current = m_Wrapped.nextElement();
                return Result;
            }
        }

        private EnumerationMethod m_Method;

        public EnumerationAdapter(EnumerationMethod method)
        {
            if (method == null)
                throw new ArgumentException();
            m_Method = method;
        }

        // IEnumerable
        public IEnumerator GetEnumerator()
        {
            return new EnumerationWrapper(m_Method);
        }
    }
}
