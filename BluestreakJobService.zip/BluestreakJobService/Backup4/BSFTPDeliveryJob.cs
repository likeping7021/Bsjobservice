﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.AccessControl;
using System.Text.RegularExpressions;
using CHILKATFTPLib;


namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concrete a class to Ftp delivery the file to client
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>06/22/2008</date>
    public class BSFTPDeliveryJob : BSJob
    {
        #region private member
        private string _ftpServer;
        private string _user;
        private string _ftppassword;
        private string _ftpPath;
        private string _placementSheetName;
        #endregion private member

        public override void Run()
        {
            int jobId = 0;
            string tafficSheetsFullName = string.Empty;
            char[] seperator = { ';' };

            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSFTPDeliveryJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, FTP delivery job started", _queueId, jobId), jobId);

                SetParameterValues();
                GetTrafficSheetsFilleName(_queueId, ref tafficSheetsFullName);

                string[] trafficSheetName = tafficSheetsFullName.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < trafficSheetName.Count(); i++)
                {
                    FTPdelivery(trafficSheetName[i]);
                }

                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, FTP delivery job compeleted successfully", _queueId, jobId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, FTP delivery job failed with Error: {2}", _queueId, jobId, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetFTPJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                _ftpServer = _oQuery.FieldByName("HOST").AsString;
                _user = _oQuery.FieldByName("UserName").AsString;
                _ftppassword = _oQuery.FieldByName("Password").AsString;
                _ftpPath = _oQuery.FieldByName("Path").AsString;
                _placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
            }
        }

        #region private method
        /// <summary>
        /// Store the traffic sheets' full name in the database.
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void GetTrafficSheetsFilleName(int queueId, ref string tafficSheetsFullName)
        {
            _oQuery.SQL = "JobService_GetTrafficSheetsFilleName";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                tafficSheetsFullName = _oQuery.FieldByName("tafficSheetsFullName").AsString;
            }
        }

        /// <summary>
        /// Delivery the keyword sheet to client ftp site
        /// </summary>
        private void FTPdelivery(string filePath)
        {
            int connectedTimes = 3;
            ChilkatFTP ftp = new ChilkatFTP();
            ftp.Hostname = _ftpServer;
            ftp.Username = _user;
            ftp.Password = _ftppassword;

            ftp.Connect();
            ftp.ChangeRemoteDir(_ftpPath);
            bool success = ftp.IsConnected == 1 ? true : false;

            //Try to connect 3 times if connection fail
            while (!success && connectedTimes > 0)
            {
                ftp.Connect();
                connectedTimes--;
                success = ftp.IsConnected == 1 ? true : false;
                System.Threading.Thread.Sleep(10000);
            }

            if (success)
            {
                bool dirExists;
                dirExists = ftp.ChangeRemoteDir("TrafficSheet") == 1 ? true : false;
                if (!dirExists)
                {
                    success = ftp.CreateRemoteDir("TrafficSheet") == 1 ? true : false;;
                    if (!success)
                    {
                        throw new Exception("An error occurred while trying to write to the FTP Directory when processing the Keyword Sheet<"
                                + _placementSheetName + ">. Error received: Permission Denied. Please contact support@bluestreak.com if you need assistance. ;Permissions issue processing Keyword Sheet: <" + _placementSheetName + ">");
                    }
                    ftp.ChangeRemoteDir("TrafficSheet");
                }
            }
            else
            {
                throw new Exception("We are unable to connect to the ftp sever: " + _ftpServer + ". Please check the ftp server setting. ;The ftp sever: " + _ftpServer + " - Connection failed");
            }

            if (success)
            {
                success = ftp.PutFile(filePath, Path.GetFileName(filePath)) == 1 ? true : false;

                if (!success)
                {
                    string errorMessage = ftp.LastErrorText;
                    throw new Exception("An error occurred while trying to write to the FTP Directory when processing the Keyword Sheet<"
                            + _placementSheetName + ">. Error received: Permission Denied. Please contact support@bluestreak.com if you need assistance. ;Permissions issue processing Keyword Sheet: <" + _placementSheetName + ">");
                }
            }
            else
            {
                throw new Exception("We have problem to connect the ftp site: " + _ftpServer + ", please check the ftp site!");
            }

            if (!success)
            {
                throw new Exception("We have problem to connect the ftp site: " + _ftpServer + ", please check the ftp site!");
            }
        }
        #endregion private member
    }
}
