﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BluestreakJobService
{
    public class JobProcessEventArgs : EventArgs
    {
        //JobStartedEventArgs(string name, string message){}

        public JobProcessEventArgs(string message)
        {
            throw new System.NotImplementedException();
        }
    }

    public class JobStartedEventArgs : EventArgs
    {

        public JobStartedEventArgs(string message)
        {
            throw new System.NotImplementedException();
        }
    }

    public class JobFinishedEventArgs : EventArgs
    {

        public JobFinishedEventArgs(string message, int status)
        {
            throw new System.NotImplementedException();
        }
    }
}

