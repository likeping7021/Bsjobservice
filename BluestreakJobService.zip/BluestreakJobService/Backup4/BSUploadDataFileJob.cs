﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using IonDBUtils;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Create a class to upload the keywordSheet
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>04/25/2008</date>
    public class BSUploadDataFileJob : BSJob
    {
        #region private member
        private string _filePath;
        private string _tsvFilePath;
        private int _placementSheetId;
        private string _placementSheetName;
        private int _campaignId;
        private bool _ignoreFirstLine;
        private int _formatVersion;
        #endregion private member

        #region public method
        public enum ErrorCode
        {
            InvalidGeographicLocation= 1,
            InvalidPublisher = 2,
            InvalidCreativeName = 3,
            InvalidPlacementName = 4,
            InvalidPlacement = 5,
            TransactionError = 6,
        }

        /// <summary>
        /// Override the run() method, run keyword sheet import
        /// </summary>
        public override void Run()
        {
            int jobId = 0;
            string errorDescription = string.Empty;
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSUploadDataFileJob);

                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet Id: {2}, name {3} import starting", _queueId, jobId, _placementSheetId, _placementSheetName), jobId);
                SetParameterValues();
                errorDescription = BulkInsertFile(this._queueId, jobId, this._tsvFilePath, this._placementSheetId, this._campaignId, _ignoreFirstLine, _placementSheetName);
                if (errorDescription == string.Empty)
                {
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet Id: {2}, name {3} import compeleted successfully", _queueId, jobId, _placementSheetId, _placementSheetName), jobId, JobStatus.Successful);
                }
                else
                {
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet Id: {2}, name {3} import failed with Error: {3}", _queueId, jobId, _placementSheetId, _placementSheetName, errorDescription), jobId, JobStatus.Failed);
                    throw new Exception("There are keyword import errors");
                }
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, keyword sheet Id: {2}, name {3} import failed with Error: {3}", _queueId, jobId, _placementSheetId, _placementSheetName, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._campaignId = _oQuery.FieldByName("campaign_id").AsInteger;
                this._placementSheetId = _oQuery.FieldByName("placementSheet_id").AsInteger;
                this._placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                this._filePath = _oQuery.FieldByName("filePath").AsString;
                this._tsvFilePath = _oQuery.FieldByName("tsvFilePath").AsString;
                this._ignoreFirstLine = _oQuery.FieldByName("Ignore_FirstLine").AsString.ToUpper() == "TRUE" ? true : false;
            }

            _oQuery.SQL = "ion_getPlacementSheetProperties";
            _oQuery.ParamByName("campaignID").AsInteger = _campaignId;
            _oQuery.ParamByName("placementSheetID").AsInteger = _placementSheetId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._formatVersion = _oQuery.FieldByName("formatVersion").AsInteger;
            }
        }
        #endregion public method

        #region private method
        /// <summary>
        /// Bulk insert the file to Database
        /// </summary>
        /// <Author>Keping Li</Author>
        /// <date>05/06/2008</date>
        private string BulkInsertFile(int queueId, int jobId, string tsvFilePath, int placementSheetId, int campaignid, bool IgnoreFirstLine, string placementSheetName)
        {
            //insert the KeywordsSheet in DB
            ErrorCode returnCode;
            int rowIndex = 0;
            string errorDescription = string.Empty;

            string ErrorFilePath = ConfigurationSettings.AppSettings["ErrorLogFilePath"].ToString();
            string ErrorFileName = ErrorFilePath + "\\Error\\JobServiceError_" + _campaignId + "_" + placementSheetId + " _" + placementSheetName + "_" + string.Format("{0:yyyyMMdd}", DateTime.Now) + ".log";

            if (File.Exists(ErrorFileName))
            {
                PublicFunctionUtil.CheckWriteLock(ErrorFileName);
                File.Delete(ErrorFileName);
            }

            if (File.Exists(tsvFilePath))
            {
                PublicFunctionUtil.CheckWriteLock(tsvFilePath);
            }

            _oQuery.SQL = "ion_importKeywordFile";
            _oQuery.ParamByName("queue_id").AsInteger = queueId;
            _oQuery.ParamByName("job_id").AsInteger = jobId;
            _oQuery.ParamByName("placementSheetId").AsInteger = placementSheetId;
            _oQuery.ParamByName("campaignID").AsInteger = campaignid;
            _oQuery.ParamByName("fileName").AsString = tsvFilePath;
            _oQuery.Open(Convert.ToInt32(ConfigurationSettings.AppSettings["BulkInsertTimeOut"].ToString()));

            //Check the return errorCode:
            while (!_oQuery.EOF())
            {
                returnCode =(ErrorCode) _oQuery.FieldByName("errorCode").AsInteger;
                rowIndex = _oQuery.FieldByName("row").AsInteger;

                if (IgnoreFirstLine)
                {
                    rowIndex++;
                }

                switch (returnCode)
                {
                    case ErrorCode.InvalidGeographicLocation:
                        errorDescription = "'" + _oQuery.FieldByName("info").AsString + "' is an invalid Geographic Location";
                        break;
                    case ErrorCode.InvalidPublisher:
                        errorDescription = "'" + _oQuery.FieldByName("info").AsString + "' is an invalid Publisher";
                        break;
                    case ErrorCode.InvalidCreativeName:
                        if (this._formatVersion == 1)
                        {
                            errorDescription = "Creative name '" + _oQuery.FieldByName("info").AsString + "' already belongs to a non-text creative";//old format
                        }
                        else
                        {
                            errorDescription = "Ad Group Name '" + _oQuery.FieldByName("info").AsString + "' already belongs to a non-text creative";//new format
                        }
                        break;
                    case ErrorCode.InvalidPlacementName:
                        if (this._formatVersion == 1)
                        {
                            errorDescription = "Placement Name '" + _oQuery.FieldByName("info").AsString + "' already belongs to a non-keyword placement";//old format
                        }
                        else
                        {
                            errorDescription = "SE Campaign '" + _oQuery.FieldByName("info").AsString + "' already belongs to a non-keyword placement";//new format
                        }
                        break;
                    case ErrorCode.InvalidPlacement:
                        if (this._formatVersion == 1)
                        {
                            errorDescription = "Placement already exists and cannot be assigned to this placement sheet";//old format
                        }
                        else
                        {
                            errorDescription = "SE Campaign already exists and cannot be assigned to this placement sheet";//new format
                        }
                        break;
                    case ErrorCode.TransactionError:
                        errorDescription = "Transaction error during import";
                        break;
                }

                if (returnCode != 0)
                {
                    WriteErrors(rowIndex, errorDescription, campaignid, placementSheetId, placementSheetName);
                }
                _oQuery.Next();
            }

            string cleanFile = ConfigurationSettings.AppSettings["DeleteTSVANDCSV"].ToString().ToUpper();
            if (cleanFile == "YES")
            {
                if (Path.GetFileName(_filePath).ToUpper() != "KEYWORDSHEET.CSV")
                {
                    PublicFunctionUtil.Cleanfile(_filePath);
                }
                PublicFunctionUtil.Cleanfile(tsvFilePath);
            }

            return errorDescription;
        }

        /// <summary>
        /// This function is to write down the error information to a file
        /// </summary>
        /// <param name="lineNumber"></param>
        /// <param name="errorDescription"></param>
        private void WriteErrors(int lineNumber, string errorDescription, int campaignid, int placementSheetId, string placementSheetName)
        {
            if (lineNumber < 0)
            {
                lineNumber = 0;
            }

            TransactionLog.Error(lineNumber.ToString(), errorDescription, campaignid.ToString(), placementSheetId.ToString(), placementSheetName);
        }
        #endregion private method
    }
}
