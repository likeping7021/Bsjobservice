﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Configuration;
using System.Collections;

namespace Bluestreak.BSJobService
{
    public class BSFileDeleteJob : BSJob
    {
        #region private data
        private string _time;
        //private string [] _fileNames;
        #endregion private data
        public override void Run()
        {
            int jobId = 0;
            char[] seperator = { ';' };
            string overDateTrafficSheetFileNames = string.Empty;
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSFileDeleteJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, file delete job started", _queueId, jobId), jobId);

                SetParameterValues();
                overDateTrafficSheetFileNames = GetOverDateFiles();

                if (overDateTrafficSheetFileNames.Length > 0)
                {
                    string[] fileNames = overDateTrafficSheetFileNames.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < fileNames.Count(); i++)
                    {
                        PublicFunctionUtil.Cleanfile(fileNames[i]);
                    }
                }

                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, file delete job compeleted successfully", _queueId, jobId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, file delete job failed with Error: {3}", _queueId, jobId, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        public override void SetParameterValues()
        {
        }

        private string GetOverDateFiles()
        {
            string overDateTrafficSheetFileNames = string.Empty;
            int lookBackDays = Convert.ToInt32("-" + ConfigurationSettings.AppSettings["OverDateDays"].ToString());
            DateTime overDate = DateTime.Now.AddDays(lookBackDays);

            _oQuery.SQL = "JobService_GetOverDateTrafficSheetFileNames";
            _oQuery.ParamByName("overDate").AsDateTime = overDate;
            _oQuery.Open();

            while (!_oQuery.EOF())
            {
                char[] seperator = { ';' };
                overDateTrafficSheetFileNames += _oQuery.FieldByName("tafficSheetsFullName").AsString.Trim() +  ";";
                _oQuery.Next();
            }

            if (overDateTrafficSheetFileNames.Length > 0)
            {
                overDateTrafficSheetFileNames = overDateTrafficSheetFileNames.Substring(0, overDateTrafficSheetFileNames.Length - 1);
            }

            return overDateTrafficSheetFileNames;
        }
    }
}
