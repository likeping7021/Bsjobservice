﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Collections;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Create a classe to proccess keyword traffic sheet
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>05/22/2008</date>
    class BSKeywordTrafficProcessJob : BSJob
    {
        #region private member
        private ArrayList _pubisherIdList;
        private int _advid;
        private int _useId;
        private int _campaignId;
        private int _placementSheetId;
        private string _placementSheetName;
        private string _traffickerEmail;
        private bool _useSpecialLaurentFrDomain;
        #endregion private member

        #region public method
        /// <summary>
        /// Override the run() method, run keyword sheet import
        /// </summary>
        public override void Run()
        {
            int jobId=0;
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSKeywordTrafficProcessJob);
                this.LogStart(string.Format("Job Queue id: {0}, job id: {1}, placement sheet Id {2} traffic process started", _queueId, jobId, _placementSheetId), jobId);
                SetParameterValues();
                KeywordTrafficProcess();
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, placement sheet Id {2} traffic process  compeleted successfully", _queueId, jobId, _placementSheetId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1}, placement sheet Id {2} traffic process failed with Error: {3}", _queueId,  jobId,_placementSheetId, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._advid = _oQuery.FieldByName("adv_id").AsInteger;
                this._useId = _oQuery.FieldByName("owner_User_id").AsInteger;
                this._campaignId = _oQuery.FieldByName("campaign_id").AsInteger;
                this._placementSheetId = _oQuery.FieldByName("placementSheet_id").AsInteger;
                this._placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                this._traffickerEmail = _oQuery.FieldByName("Email_notification").AsString;
                this._useSpecialLaurentFrDomain = _oQuery.FieldByName("UseSpecialLaurentFrDomain").AsString.ToUpper() == "TRUE" ? true : false;
            }
        }
        #endregion public method

        #region private method
        /// <summary>
        /// Process keyword traffic
        /// </summary>
        private void KeywordTrafficProcess()
        {
            string tokenForPickUp =string.Empty;
            _pubisherIdList = new ArrayList();
            GetPublisherIDs(_placementSheetId);

            //Traffic process each of the publisher for the keyword placement sheet
            foreach (int publisherId in _pubisherIdList)
            {
                string token = string.Empty;
                string publisherEmails = GetPublisherEmails(publisherId);
                string customtext = string.Empty;
                _oQuery.SQL = "ion_trafficPlacementSheet";
                _oQuery.ParamByName("campaignID").AsInteger = this._campaignId;
                _oQuery.ParamByName("placementSheetID").AsInteger = this._placementSheetId;
                _oQuery.ParamByName("publisherID").AsInteger = publisherId;
                _oQuery.ParamByName("traffickerEmail").AsString = this._traffickerEmail;
                _oQuery.ParamByName("userID").AsInteger = this._useId;
                _oQuery.ParamByName("sentEmail").AsString = publisherEmails == string.Empty ? this._traffickerEmail : publisherEmails;
                _oQuery.ParamByName("useSpecialLaurentFrDomain").AsTinyInt= _useSpecialLaurentFrDomain == true ? 1: 0;
                _oQuery.Open(Convert.ToInt32(ConfigurationSettings.AppSettings["TrafficSheetProcessTimeOut"].ToString()));
                customtext = "Traffic Sheets:" + "\n" + _placementSheetName;
                SaveEmailData(publisherId, customtext, ref token);
                tokenForPickUp += token + ";";
            }

            if (tokenForPickUp.Length > 0)
            {
                tokenForPickUp = tokenForPickUp.Substring(0, tokenForPickUp.Length - 1);
                StoreTokenForPickUp(tokenForPickUp);
            }
        }

        /// <summary>
        /// Get the publisher contact Email lists
        /// </summary>
        /// <param name="publishId"></param>
        /// <param name="placementSheetId"></param>
        private string GetPublisherEmails(int publisherId)
        {
            string publisherEmails = string.Empty;

            _oQuery.SQL = "spl_ION22AK_TrafficControl_getPublisherEmails";
            _oQuery.ParamByName("advid").AsInteger = this._advid;
            _oQuery.ParamByName("campaignID").AsInteger = this._campaignId;
            _oQuery.ParamByName("pubid").AsInteger = publisherId;
            _oQuery.Open(600);

            if (!_oQuery.EOF())
            {
                publisherEmails = _oQuery.FieldByName("pubemails").AsString;
            }
            return publisherEmails;
        }

        /// <summary>
        /// Get the publisher ids for the uploaded keyword placement sheet
        /// </summary>
        /// <param name="publishId"></param>
        /// <param name="placementSheetId"></param>
        private void GetPublisherIDs( int placementSheetId)
        {
            int publisherId;
            _oQuery.SQL = "JobService_GetPublishIdForPlacementSheet";
            _oQuery.ParamByName("placementSheetId").AsInteger = placementSheetId;
            _oQuery.Open();

            while (!_oQuery.EOF())
            {
                publisherId = _oQuery.FieldByName("publisherId").AsInteger;
                _pubisherIdList.Add(publisherId);
                _oQuery.Next();
            }
        }

        /// <summary>
        /// Save the email data and token for pick up
        /// </summary>
        private void SaveEmailData(int publisherId, string customtext, ref string token)
        {
            _oQuery.SQL = "JobService_ION242_TrafficControl_getCustomPickupPageToken";
            _oQuery.ParamByName("campaignid").AsInteger = _campaignId;
            _oQuery.ParamByName("pubid").AsInteger = publisherId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                token = _oQuery.FieldByName("token").IsNull ? string.Empty : _oQuery.FieldByName("token").AsString.Trim();
            }

            if (token == string.Empty || token == "")
            {
                int rand = new Random().Next(1, 100000);
                token = "advid=" + _advid.ToString() + "&campaignid=" + _campaignId.ToString() + "&pubid=" + publisherId.ToString();
                token = token + "&tstamp=" + DateTime.Now + "&rnd=" + rand.ToString();
                token = PublicFunctionUtil.CalcMD5(token);
            }

            _oQuery.SQL = "spl_ION22AK_TrafficControl_setPublisherEmails";
            _oQuery.ParamByName("advid").AsInteger = _advid;
            _oQuery.ParamByName("campaignid").AsInteger = _campaignId;
            _oQuery.ParamByName("pubid").AsInteger = publisherId;
            _oQuery.ParamByName("pubemails").AsString = _traffickerEmail;
            _oQuery.ParamByName("customtext").AsString = customtext;
            _oQuery.ParamByName("token").AsString = token;
            _oQuery.Open();
        }

        /// <summary>
        /// Store the traffic sheets' full name in the database.
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void StoreTokenForPickUp(string tokenForPickUp)
        {
            _oQuery.SQL = "JobService_SaveStoreTokenForPickUp";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("tokenForPickUp").AsString = tokenForPickUp;
            _oQuery.Open();
        }
        #endregion private method
    }
}
