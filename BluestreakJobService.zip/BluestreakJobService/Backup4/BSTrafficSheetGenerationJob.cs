﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using System.Configuration;
using System.Collections;
using Bluestreak.GetTrafficSheet;


namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Create a class to generate traffic sheet for the user to pick up
    /// </summary>
    /// <Author>Keping Li</Author>
    /// <Copyright>Bluestreak</Copyright>
    /// <date>05/23/2008</date>
    class BSTrafficSheetGenerationJob : BSJob
    {
        #region private member 
        private int _placementSheetId;
        private string _trafficSheetPath;
        private ArrayList _trafficSheetIdList;
        private int _trafficRecent;
        #endregion private member

        #region public method
        /// <summary>
        /// Override the run() method, run keyword sheet import
        /// </summary>
        public override void Run()
        {
            int jobId = 0;
            string trafficSheetsFullName = string.Empty;
            string placementSheetName = string.Empty;
            string trafficSheetIds = string.Empty;
            CSVFormat trafficFileFormat;

            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSTrafficSheetGenerationJob);
                SetParameterValues();
                trafficFileFormat = GetCSVFormat(_placementSheetId, ref placementSheetName);

                this.LogStart(string.Format("Job Queue id: {0}, job id: {1} generating traffic sheet for placement sheet {2} starting", _queueId, jobId, placementSheetName), jobId);
                GetTrafficSheetIDs(_placementSheetId);
                
                foreach (int trafficSheetId in _trafficSheetIdList)
                {
                    TrafficSheet generateTrafficSheet = new TrafficSheet();

                    trafficSheetsFullName += generateTrafficSheet.GenerateTrafficSheet(trafficSheetId, _trafficSheetPath, Convert.ToInt32(trafficFileFormat), _trafficRecent, placementSheetName) + ";";
                    generateTrafficSheet.Dispose();
                    trafficSheetIds += trafficSheetId.ToString() + ";";
                }

                if (_trafficSheetIdList.Count != 0)
                {
                    trafficSheetIds = trafficSheetIds.Substring(0, trafficSheetIds.Length - 1);
                    trafficSheetsFullName = trafficSheetsFullName.Substring(0, trafficSheetsFullName.Length - 1);
                    StoreTrafficSheetsFilleName(trafficSheetsFullName, trafficSheetIds);
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1} generating traffic sheet for placement sheet  {2} compeleted successfully", _queueId, jobId, placementSheetName), jobId, JobStatus.Successful);
                }
                else
                {
                    this.LogEnd(string.Format("Job Queue id: {0}, job id: {1} generating traffic sheet for placement sheet {2} failed with Error: no data in the file", _queueId, jobId, placementSheetName), jobId, JobStatus.Failed);
                    throw new Exception (" there is no data in the uploaded file.");
                }
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1} generating traffic sheet for placement sheet {2} failed with Error: {2}", _queueId, jobId, placementSheetName, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            _oQuery.SQL = "JobService_GetJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._placementSheetId = _oQuery.FieldByName("placementSheet_id").AsInteger;
                this._trafficSheetPath = Path.GetDirectoryName(_oQuery.FieldByName("filePath").AsString) + "\\" + "trafficSheets";
                this._trafficRecent = _oQuery.FieldByName("trafficRecent").AsString.ToUpper() == "TRUE" ? 1 : 0;
                //this._trafficSheetPath = ConfigurationSettings.AppSettings["trafficSheetPath"].ToString(); 
                this._trafficSheetIdList = new ArrayList();
            }
        }
        #endregion public method

        #region private method
        /// <summary>
        /// Get the scv file format for the uploaded keyword placement sheet
        /// </summary>
        private CSVFormat GetCSVFormat(int placementSheetId, ref string placementSheetName)
        {
            CSVFormat fileFormat;
            _oQuery.SQL = "JobService_GetCSVFormat";
            _oQuery.ParamByName("placementSheetId").AsInteger = placementSheetId;
            _oQuery.Open();

            fileFormat = _oQuery.FieldByName("CSVFormat").AsInteger == 0 ? CSVFormat.Ascii : CSVFormat.UTF16;
            placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
            return fileFormat;
        }

        /// <summary>
        /// Get the publisher ids for the uploaded keyword placement sheet
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void GetTrafficSheetIDs(int placementSheetId)
        {
            int trafficSheetId;
            _oQuery.SQL = "JobService_GetTrafficSheetIdAfterPlaceSheetProcess";
            _oQuery.ParamByName("placementSheetId").AsInteger = placementSheetId;
            _oQuery.Open();

            while (!_oQuery.EOF())
            {
                trafficSheetId = _oQuery.FieldByName("trafficSheetId").AsInteger;
                _trafficSheetIdList.Add(trafficSheetId);
                _oQuery.Next();
            }
        }

        /// <summary>
        /// Store the traffic sheets' full name in the database.
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void StoreTrafficSheetsFilleName(string trafficSheetsFullName, string trafficSheetIds)
        {
            _oQuery.SQL = "JobService_SaveTrafficSheetsFilleName";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = _queueId;
            _oQuery.ParamByName("trafficSheetsFullName").AsString = trafficSheetsFullName;
            _oQuery.ParamByName("trafficSheetIds").AsString = trafficSheetIds;
            _oQuery.Open();
        }
        #endregion private method
    }
}
