﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Configuration;
using System.Threading;

namespace Bluestreak.BSJobService
{
    /// <summary>
    /// Concrate a class to send an email
    /// </summary>
    /// <author>Keping Li</author>
    /// <date>12/10/2007</date>
    public class BSEmailJob : BSJob
    {
        #region Private data
        private string _emailFrom;
        private string _emailTos;
        private string _emailCCs = string.Empty;
        private string _emailSubject = string.Empty;
        private string _emailMessage = string.Empty;
        private string _emailSmtp;
        private string _emailAttachmentFileName = string.Empty;

        private int _Advid;
        private int _campaignId;
        private string _placementSheetName = string.Empty;
        private string _campaignName = string.Empty;
        private string _AdvertiserName = string.Empty;
        private string _publisher = string.Empty;
        private int _scheduleId = 0;
        #endregion Private data

        #region Public Method
        /// <summary>
        /// Override the run() method, run keyword sheet import
        /// </summary>
        public override void Run()
        {
            bool isOversize = false;
            int jobId = 0;
            string tokenForPickUp = string.Empty;
            string tafficSheetsFullName = string.Empty;
            string trafficSheetIds = string.Empty;
            bool CampaignNameExist;
            char[] seperator = { ';' };
            try
            {
                jobId = this.GetJobId(_queueId, JobType.BSEmailJob);

                this.LogStart(string.Format("Job Queue id: {0}, job id: {1} sending email started", _queueId, jobId), jobId);
                SetParameterValues();

                GetTrafficSheetsFilleName(_queueId, ref tafficSheetsFullName, ref tokenForPickUp, ref trafficSheetIds);
                string[] trafficSheetName = tafficSheetsFullName.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                string[] token = tokenForPickUp.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                string[] trafficSheetId = trafficSheetIds.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                string[] zipTrafficSheetName = new string[trafficSheetName.Count()];
                
                _emailAttachmentFileName = string.Empty;

                int count = trafficSheetName.Count() >= token.Count() ? trafficSheetName.Count() : token.Count();
                for (int i = 0; i < count; i++)
                {
                    zipTrafficSheetName[i] = Path.GetDirectoryName(trafficSheetName[i]) + "\\" + "TrafficSheets_" + this._Advid + "_" + this._campaignId + "_" + trafficSheetId[i] + "_" + string.Format("{0:yyyyMMddhhmmss}", DateTime.Now) + ".zip";
                    Thread.Sleep(1000);
                    _emailAttachmentFileName += zipTrafficSheetName[i] + ";";
                    PublicFunctionUtil.Zipfile(trafficSheetName[i], zipTrafficSheetName[i]);
                    if (!isOversize)
                    {
                        isOversize = PublicFunctionUtil.CheckFileSize(zipTrafficSheetName[i], Convert.ToInt64(ConfigurationSettings.AppSettings["MaxEmailSize"].ToString()));
                    }

                    _emailMessage += "<a href=" + "http://" + ConfigurationSettings.AppSettings["HOST"].ToString() + "/pickuppub.asp?id=" + token[i] + "&eventIDs= " + "target='_blank'" + ">" + "http://" + ConfigurationSettings.AppSettings["HOST"].ToString() + "/pickuppub.asp?id=" + token[i] + "&eventIDs=" + "</A>" + "<br>" + "<br>";
                }

                if (this._scheduleId > 0)
                {
                    _emailMessage += "</li>";
                    _emailMessage += "<li>If your FTP site was configured, the traffic sheet was delivered to the /TrafficSheet folder.</li>";
                    _emailMessage += "</ol>";
                }

                if (!isOversize)
                {
                    SendMailMessage(seperator, true);
                }
                else
                {
                    SendMailMessage(seperator, false);
                }

                //Delete the zip file after send email
                for (int i = 0; i < zipTrafficSheetName.Count(); i++)
                {
                    PublicFunctionUtil.Cleanfile(zipTrafficSheetName[i]);
                }
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1} sending email compeleted successfully", _queueId, jobId), jobId, JobStatus.Successful);
            }
            catch (Exception ex)
            {
                this.LogEnd(string.Format("Job Queue id: {0}, job id: {1} sending email failed with Error: {2}", _queueId, jobId, ex.Message), jobId, JobStatus.Failed);
                throw ex;
            }
        }

        /// <summary>
        /// Set the job parameters' values 
        /// </summary>
        public override void SetParameterValues()
        {
            string emailNotification = string.Empty;
            string placementSheetName = string.Empty;
            _oQuery.SQL = "JobService_GetJobParameterValues";
            _oQuery.ParamByName("QueueId").AsInteger = _queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                this._emailFrom = ConfigurationSettings.AppSettings["EmailSender"].ToString();
                //this._emailFrom = _oQuery.FieldByName("TraffickerEmailAddress").AsString;
                emailNotification = _oQuery.FieldByName("Email_notification").AsString; 
                placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                if (emailNotification.IndexOf(";") > 0)
                {
                    //More than one email address
                    this._emailTos = emailNotification.Substring(0, emailNotification.IndexOf(";")).Trim();
                    this._emailCCs = emailNotification.Substring(this._emailTos.Length + 1, emailNotification.Length - this._emailTos.Length - 1).Trim();
                }
                else
                {
                    //Only one email address
                    this._emailTos = emailNotification.Trim();
                    this._emailCCs = "";
                }

                this._Advid = _oQuery.FieldByName("Adv_id").AsInteger;
                this._campaignId = _oQuery.FieldByName("campaign_id").AsInteger;
                this._AdvertiserName = _oQuery.FieldByName("AdvertiserName").AsString;
                this._placementSheetName = _oQuery.FieldByName("placementSheetName").AsString;
                this._publisher = _oQuery.FieldByName("publisher").AsString;

                this._campaignName = _oQuery.FieldByName("campaignName").AsString;
                this._emailSmtp = ConfigurationSettings.AppSettings["SMTP"].ToString();
                this._emailAttachmentFileName = _oQuery.FieldByName("tafficSheetsFullName").AsString;
                this._scheduleId = _oQuery.FieldByName("scheduleId").AsInteger;

                this._emailSubject = "Advertiser: " + this._AdvertiserName + " Campaign: " + this._campaignName + "  Publisher: " + this._publisher;

                if (this._scheduleId > 0)
                {
                    this._emailMessage = "Hello," + "<br>" + "<br>" + "Attached please find your traffic sheet(s) for the following campaign." + "<br>" + "<br>"
                        + "Publisher: " + this._publisher + "<br>"
                        + "Advertiser: " + this._AdvertiserName + "<br>" + "Campaign: " + this._campaignName + "<br>" + "<br>" 
                        + "<h4>" + "Traffic Sheets: " + "</h4>" + this._placementSheetName + "<br>" + "<br>"
                        + "<h4>" + "For clients with a traffic sheet greater than 2MB:" +"</h4>"
                        + "If your traffic sheet was greater than 2MB you have the following options to pick up your traffic sheet:" + "<br>" + "<br>"
                        + "<ol>"
                        + "<li> You can go to the following URL to pick up your traffic sheet:" + "<br>";
                }
                else
                {
                    //this._emailMessage = "BlueStreak Tags for Publisher: " + this._publisher + "<br>" + "<br>"
                    //    + "Advertiser: " + this._AdvertiserName + "<br>" + "Campaign: " + this._campaignName + "<br>" + "<br>" 
                    //    + "<h4>" + "Traffic Sheets: " + "</h4>" + this._placementSheetName + "<br>" + "<br>"
                    //    + "Please go to the following URL to pick up your ad tags:" + "<br>";

                    this._emailMessage = "Hello," + "<br>" + "<br>" + "Attached please find your traffic sheet(s) for the following campaign." + "<br>" + "<br>"
                    + "Advertiser: " + this._AdvertiserName + "<br>" + "Campaign: " + this._campaignName + "<br>" + "<br>"
                    + "<h4>" + "Traffic Sheets: " + "</h4>" + this._placementSheetName + "<br>" + "<br>"
                    + "<h4>" + "For clients with a traffic sheet greater than 2MB:" + "</h4>"
                    + "If your traffic sheet was greater than 2MB you have the following options to pick up your traffic sheet:" + "<br>" + "<br>";
                }
            }
        }

        /// <summary>
        /// Send an email message
        /// </summary>
        /// <author>Keping Li</author>
        /// <date>12/10/2007</date>
        public void SendMailMessage(char[] charSeparator, bool hasAttachedFile)
        {
            string emailCCs = _emailCCs.Trim().Length > 0 ? RemoveDuplicateEmails(_emailCCs, _emailTos, charSeparator) : _emailCCs;
            string[] emailTo = _emailTos.Split(charSeparator, StringSplitOptions.RemoveEmptyEntries);
            string[] emailCC = emailCCs.Split(charSeparator, StringSplitOptions.RemoveEmptyEntries);
            try
            {
                MailMessage mailMsg = new MailMessage();
                mailMsg.From = new MailAddress(_emailFrom);

                //Add all EmailTo address
                AddEmailTo(ref mailMsg, emailTo);

                //Add all EmailBcc address
                AddEmailCC(ref mailMsg, emailCC);

                //Add all atachement files
                if (hasAttachedFile)
                {
                    string[] emailAttachmentFileName = _emailAttachmentFileName.Split(charSeparator, StringSplitOptions.RemoveEmptyEntries);
                    AddFileAttachment(ref mailMsg, emailAttachmentFileName);
                }
                mailMsg.Subject = _emailSubject;
                mailMsg.Body = _emailMessage;
                mailMsg.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient(_emailSmtp);
                smtpClient.Send(mailMsg);
                mailMsg.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion Public Method

        #region Private Method
        //Add EmailTo address
        private void AddEmailTo(ref MailMessage mail, string[] emailTo)
        {
            for (int count = 0; count < emailTo.Length; count++)
            {
                mail.To.Add(new MailAddress(emailTo[count]));
            }
        }

        //Add EmailCC address
        private void AddEmailCC(ref MailMessage mail, string[] emailCC)
        {
            for (int count = 0; count < emailCC.Length; count++)
            {
                mail.To.Add(new MailAddress(emailCC[count]));
            }
        }

        //Add file attachments
        private void AddFileAttachment(ref MailMessage mail, string[] fileNames)
        {
            // Create  the file attachment for this e-mail message.
            for (int count = 0; count < fileNames.Length; count++)
            {
                Attachment file = new Attachment(fileNames[count]);
                mail.Attachments.Add(file);
            }
        }

        //Remove the duplicate email addresses
        private string RemoveDuplicateEmails(string EmailCC, string EmailTo, char[] charSeparator)
        {
            StringBuilder sb = new StringBuilder();
            string[] emailToken = _emailCCs.Split(charSeparator, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < emailToken.Count(); i++)
            {
                if (emailToken[i] != EmailTo && !sb.ToString().Contains(emailToken[i]))
                {
                    sb.Append(emailToken[i] + ";");
                }
            }
            if (sb.Length > 0)
            {
                sb.Remove(sb.Length - 1, 1);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Store the traffic sheets' full name in the database.
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void GetTrafficSheetsFilleName(int queueId, ref string tafficSheetsFullName, ref string tokenForPickUp, ref string trafficSheetIds)
        {
            _oQuery.SQL = "JobService_GetTrafficSheetsFilleName";
            _oQuery.ParamByName("Job_Queue_id").AsInteger = queueId;
            _oQuery.Open();

            if (!_oQuery.EOF())
            {
                tafficSheetsFullName = _oQuery.FieldByName("tafficSheetsFullName").AsString;
                tokenForPickUp = _oQuery.FieldByName("tokenForPickUp").AsString;
                trafficSheetIds = _oQuery.FieldByName("trafficSheetIds").AsString;
            }
        }

        /// <summary>
        /// Insert a new Compaign
        /// </summary>
        /// <param name="placementSheetId"></param>
        private void InsertNewCampaign()
        {
            _oQuery.SQL = "JobService_InsertNewCampaign";
            _oQuery.ParamByName("advid").AsInteger = _Advid;
            _oQuery.ParamByName("description").AsString = _campaignName;
            _oQuery.Open();


        }
        #endregion Private Method


        #region Properties.
        //Set the value of EmailFrom
        public string EmailFrom
        {
            set
            {
                _emailFrom = value;
            }
        }

        //Set the value of EmailTo
        public string EmailTos
        {
            set
            {
                _emailTos = value;
            }
        }

        //Set the value of EmailCCs
        public string EmailCCs
        {
            set
            {
                _emailCCs = value;
            }
        }

        //Set the value of Email subject
        public string EmailSubject
        {
            set
            {
                _emailSubject = value;
            }
        }

        //Set the value of Email Message
        public string EmailMessage
        {
            set
            {
                _emailMessage = value;
            }
        }

        //Set the value of Email Smtp
        public string EmailSmtp
        {
            set
            {
                _emailSmtp = value;
            }
        }

        //Set the value of Email Attachment FileNames
        public string EmailAttachmentFileNames
        {
            set
            {
                _emailAttachmentFileName = value;
            }
        }
        #endregion Properties
    }
}
